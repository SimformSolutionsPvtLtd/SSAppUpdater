require 'xcodeproj'
require 'optparse'

# Parse command-line arguments
options = {}
OptionParser.new do |opts|
  opts.banner = "Usage: add_files_to_xcode_project.rb [options]"

  opts.on("-pPROJECT", "--project=PROJECT", "Path to the Xcode project file") do |v|
    options[:project] = v
  end

  opts.on("-dDIRECTORY", "--directory=DIRECTORY", "Path to the directory or file containing files") do |v|
    options[:directory] = v
  end

  opts.on("-tTARGET", "--target=TARGET", "Name of the target to add files to") do |v|
    options[:target] = v
  end

  opts.on("-gGROUP", "--group=GROUP", "Group (folder) within the Xcode project to add files to") do |v|
    options[:group] = v
  end
end.parse!

# Validate input
unless options[:project] && options[:directory] && options[:target]
  puts "Error: -p (project), -d (directory), and -t (target) arguments are required."
  exit 1
end

project_path = options[:project]
path = options[:directory]
target_name = options[:target]
group_path = options[:group] || ''  # Optional group path

# Load the project
project = Xcodeproj::Project.open(project_path)

# Ensure the path exists
unless File.exist?(path)
  puts "Error: The path #{path} does not exist."
  exit 1
end

# Find the target
target = project.targets.find { |t| t.name == target_name }
unless target
  puts "Error: Target #{target_name} not found."
  exit 1
end

# Helper method to find or create a group within a given path
def find_or_create_group(main_group, group_path)
  group_names = group_path.split('/')
  current_group = main_group

  group_names.each do |name|
    existing_group = current_group.groups.find { |g| g.display_name == name }
    if existing_group
      current_group = existing_group
    else
      current_group = current_group.new_group(name)
    end
  end

  current_group
end

# Find or create the group within the project
group = find_or_create_group(project.main_group, group_path)

# Handle the path based on whether it's a file or directory
files_to_add = []
if File.directory?(path)
  # Process directory
  files_to_add = Dir.glob(File.join(path, '**', '*')).reject { |file| File.directory?(file) }
elsif File.file?(path)
  # Process single file
  files_to_add = [path]
else
  puts "Error: The path #{path} is neither a file nor a directory."
  exit 1
end

# Create a mapping of existing files in the group
existing_files = group.files.each_with_object({}) { |file, hash| hash[file.path] = file }

files_to_add.each do |file_path|
  relative_path = file_path.sub("#{File.dirname(path)}/", '')

  # Check if the file already exists in the group
  unless existing_files[relative_path]
    # Create a new file reference in the specified group
    file_ref = group.new_file(file_path)
    existing_files[relative_path] = file_ref
    puts "Added file #{file_path} to group '#{group_path}'"
  else
    file_ref = existing_files[relative_path]
    puts "File #{file_path} already exists in group '#{group_path}'"
  end

  # Add the file to the target's sources build phase if not already included
  unless target.source_build_phase.files_references.include?(file_ref)
    target.add_file_references([file_ref])
  end
end

# Save the project
project.save

puts "Files from #{path} have been added to group '#{group_path}' and target '#{target_name}' in project '#{project_path}'."
