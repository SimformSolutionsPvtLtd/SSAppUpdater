#!/bin/bash

# Check if the correct number of arguments is provided
if [ $# -ne 7 ]; then
    echo "Usage: $0 <project_path> <author_name> <company_name> <date> <project_name> <yes_no> <include_bundler>"
    echo "Example: $0 /path/to/project \"John Doe\" \"Your Company Name\" \"14/08/24\" \"MyProject\" \"yes\" \"yes\""
    exit 1
fi

# Arguments
project_path="$(echo "$1" | sed 's/\\//g')"
author_name="$2"
company_name="$3"
date="$4"
project_name="$5"
yes_no="$6"
include_bundler="$7"

# Change directory to the specified project path
cd "$project_path" || { echo "Error: Directory not found"; exit 1; }

# Conditionally run the header injection script based on the yes_no argument
if [ "$yes_no" = "yes" ]; then
    echo "Running header_injection.sh with arguments: $author_name, $company_name, $date, $project_name"
    bash header_injection.sh "$author_name" "$company_name" "$date" "$project_name"
else
    pod deintegrate
    echo "Skipping header_injection.sh"
fi

# Conditionally run Bundler commands based on the include_bundler argument
if [ "$include_bundler" = "yes" ]; then
    echo "Updating bundler..."
    bundle update
    bundle install
    bundle update --bundler
    echo "Running Arkana..."
    bundle exec arkana
fi

# Always run these commands
echo "Skipping Bundler commands and Arkana."
pod repo update

echo ""
echo "Running pod install in $project_path..."
pod install
