#!/bin/bash

# Check for Command Line Tools
sudo xcode-select -s /Applications/Xcode.app/Contents/Developer

if ! xcode-select -p &> /dev/null; then
    echo "Command Line Tools not found. Installing Command Line Tools..."
    xcode-select --install
    echo "Please follow the instructions in the pop-up window to complete the installation."
    exit 1
else
    echo "Command Line Tools are installed."
fi

# Check if Homebrew is installed
if ! command -v brew &> /dev/null; then
    echo "Homebrew not found. Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL   https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

    # Verify Homebrew installation
    if command -v brew &> /dev/null; then
        echo "Homebrew installation successful."
    else
        echo "Homebrew installation failed."
        eval $(/opt/homebrew/bin/brew shellenv)
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        exit 1
    fi
else
    echo "Homebrew is already installed."
fi

# Function to run a command and print it
run_command() {
  local command="$1"
  echo "Running: $command"
  eval "$command"
}

# Function to check if a command exists
check_command() {
  local command="$1"
  command -v "$command" > /dev/null 2>&1
}

# Function to check if a file contains a specific pattern
check_file_contains() {
  local filepath="$1"
  local pattern="$2"
  grep -q "$pattern" "$filepath"
}

# Check and install ruby-build if not installed
if ! check_command 'ruby-build'; then
  echo "ruby-build not found. Installing..."
  run_command "brew install ruby-build"
else
  echo "ruby-build is already installed."
fi

# Check and install rbenv if not installed
if ! check_command 'rbenv'; then
  echo "rbenv not found. Installing..."
  run_command "brew install rbenv"
else
  echo "rbenv is already installed."
fi

# Configure rbenv in ~/.zshrc if not already configured
zshrc_path="$HOME/.zshrc"
if ! check_file_contains "$zshrc_path" 'rbenv'; then
  echo "Configuring rbenv in ~/.zshrc..."
  run_command 'echo "export PATH=\"$HOME/.rbenv/bin:$PATH\"" >> ~/.zshrc'
  run_command 'echo "eval \"$(rbenv init -)\"" >> ~/.zshrc'
else
  echo "rbenv is already configured in ~/.zshrc."
fi

if check_command 'rbenv'; then
  ruby_version='3.1.3'
  if ! rbenv versions | grep -q "$ruby_version"; then
    echo "Installing Ruby $ruby_version..."
    run_command "rbenv install $ruby_version"
  else
    echo "Ruby $ruby_version is already installed."
  fi

  current_global_version=$(rbenv global)
  if [ "$current_global_version" != "$ruby_version" ]; then
    echo "Setting global Ruby version to $ruby_version..."
    run_command "rbenv global $ruby_version"
  else
    echo "Global Ruby version is already set to $ruby_version."
  fi
else
  echo "rbenv is not installed. Skipping Ruby installation."
fi

echo "All commands executed. You might need to restart your terminal or run 'source ~/.zshrc' to apply the changes."


# Check if CocoaPods is installed
if ! command -v pod &> /dev/null; then
    echo "CocoaPods not found. Installing CocoaPods..."
    # Install CocoaPods using Homebrew
    if brew install cocoapods; then
        echo "CocoaPods installation complete."
    else
        echo "CocoaPods installation failed."
        exit 1
    fi
else
    echo "CocoaPods is already installed."
fi

if ! command -v bundle &> /dev/null
then
    echo "Bundler is not installed. Installing Bundler..."
    gem install bundler

    # Check if installation was successful
    if [ $? -eq 0 ]; then
        echo "Bundler installed successfully."
    else
        echo "Failed to install Bundler. Please install it manually."
        exit 1
    fi
else
    echo "Bundler is already installed."
fi

if ! command -v xcodegen &> /dev/null
then
    echo "Xcodegen is not installed. Installing xcodegen..."
    brew install xcodegen

    # Check if installation was successful
    if [ $? -eq 0 ]; then
        echo "xcodegen installed successfully."
    else
        echo "Failed to install xcodegen. Please install it manually."
        exit 1
    fi
else
    brew upgrade xcodegen
    echo "Bundler is already installed."
fi

if ! command -v xcodeproj &> /dev/null
then
    echo "xcodeproj is not installed. Installing Bundler..."
    brew install xcodeproj

    # Check if installation was successful
    if [ $? -eq 0 ]; then
        echo "xcodeproj installed successfully."
    else
        echo "Failed to install xcodeproj. Please install it manually."
        exit 1
    fi
fi
