import Foundation

/// Enum representing the folder names in AWSS3 bucket
public enum AWSFolderName: String {
    case avatar
}
