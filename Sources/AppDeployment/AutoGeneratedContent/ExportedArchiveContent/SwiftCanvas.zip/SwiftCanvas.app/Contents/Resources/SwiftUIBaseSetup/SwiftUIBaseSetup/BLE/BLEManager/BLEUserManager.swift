import UIKit

private struct BLEConstants {
    // NSUserDefaults persistence keys
    static let txPower = "txPower"
    static let backgroundMode = "backgroundMode"
}

let bleUserManager = BLEUserManager.shared

public class BLEUserManager {
    
    // static properties get lazy evaluation and dispatch_once_t for free
    private struct Static {
        static let instance = BLEUserManager()
    }
    
    // this is the Swift way to do singletons
    class var shared: BLEUserManager {
        return Static.instance
    }
    
    // user authentication always begins with a UUID
    private let userDefaults = UserDefaults.standard
    
    var txPower: Double {
        get {
            if BLEUserManager.exists(key: BLEConstants.txPower) {
                return userDefaults.double(forKey: BLEConstants.txPower)
            } else {
                return -59
            }
        }
        set (newValue) {
            userDefaults.set(newValue, forKey: BLEConstants.txPower)
            userDefaults.synchronize()
        }
    }
    
    var isBackgroundEnabled: Bool {
        get {
            return userDefaults.bool(forKey: BLEConstants.backgroundMode)
        }
        set (newValue) {
            userDefaults.set(newValue, forKey: BLEConstants.backgroundMode)
            userDefaults.synchronize()
        }
    }
}

extension BLEUserManager {

    // MARK: - Clear all data
    func clearAllData() {
        userDefaults.removeObject(forKey: BLEConstants.txPower)
        userDefaults.synchronize()
    }
}

extension BLEUserManager {

    static func exists(key: String) -> Bool {
        return UserDefaults.standard.object(forKey: key) != nil
    }
}

