import Foundation
import CoreBluetooth

// Specify GATT "Assigned Numbers" as
// constants so they're readable and updatable

// MARK: - CoreBluetooth service IDs
let hrmHeartRateServiceUUID = "180D"
let hrmDeviceInfoServiceUUID = "180A"
let hrmBatteryServiceUUID = "180F"

// MARK: - CoreBluetooth characteristic IDs
let hearRateServiceUUID = "2A39"
let batteryLevelUUID = "2A19"
let manufactureNameString = "2A29"
let bodySensorLocation = "2A38"
let hearRateMeasurement = "2A37"

/// This class adopts both the central and peripheral delegates and therefore must conform to these protocols' requirements
class BluetoothPeripheralManager: NSObject {

    /// Shared variable
    public static let shared = BluetoothPeripheralManager()

    // MARK: - Variable
    var deviceList = [CBPeripheral]()
    var centralManager = CBCentralManager()
    var refreshDeviceList: ((_ list: [CBPeripheral]?) -> Void)?
    var connectedPeripheral: CBPeripheral?
    var batteryPercentage: Int?
    var sensorLocation: String?
    var updateHeartBeat: ((_ heartBeat: String?) -> Void)?
    var deviceName: String?

    override init() {
        super.init()
        // create a central to scan for, connect to,
        // manage, and collect data from peripherals
        centralManager.delegate = self
    }

    /// Scan for peripherals
    func startScan() {
        let heartReteServices = CBUUID.init(string: hrmHeartRateServiceUUID)
        let services = [heartReteServices]
        // in this use-case, start scanning
        // for the same peripheral or another, as long
        // as they're HRMs, to come back online
        centralManager.scanForPeripherals(withServices: services, options: nil)
    }

    /// Stop scan for peripherals
    func stopScan() {
        centralManager.stopScan()
    }

    /// Connect peripheral
    /// - Parameter peripheral: peripheral to connect
    func connectDevice(peripheral: CBPeripheral) {
        self.connectedPeripheral = peripheral
        // connect to the discovered peripheral of interest
        self.centralManager.connect(peripheral, options: [CBConnectPeripheralOptionNotifyOnDisconnectionKey: true])
    }

    /// Disconnect peripheral
    /// - Parameter peripheral: peripheral to disconnect
    func disconnectDevice(peripheral: CBPeripheral) {
        self.centralManager.cancelPeripheralConnection(peripheral)
        self.connectedPeripheral = nil
    }
}

 // MARK: - CBCentralManagerDelegate methods
extension BluetoothPeripheralManager: CBCentralManagerDelegate {
    //  this method is called based on
    // the device's Bluetooth state; we can ONLY
    // scan for peripherals if Bluetooth is .poweredOn
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .unknown:
            print("unknown state")
        case .resetting:
            print("unknown state")
        case .unsupported:
            print("unsupported state")
        case .unauthorized:
            print("unauthorized state")
        case .poweredOff:
            self.stopScan()
        case .poweredOn:
            print("poweredOn state")
        @unknown default:
            print("@unknown state")
        }
    }

    // Invoked when a connection is successfully created with a peripheral.
    // we can only move forwards when we know the connection
    // to the peripheral succeeded
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        self.connectedPeripheral = peripheral
        self.deviceName = peripheral.name
        connectedPeripheral?.delegate = self
        connectedPeripheral?.discoverServices(nil)
    }

    // when a peripheral disconnects, take
    // use-case-appropriate action
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        if let error = error {
            print(error.localizedDescription)
        } else {
            print(peripheral)
        }
    }
}

// MARK: - CBPeripheralDelegate methods
extension BluetoothPeripheralManager: CBPeripheralDelegate {

    // Discover what peripheral devices OF INTEREST
    // are available for this app to connect to
    func centralManager(
        _ central: CBCentralManager,
        didDiscover peripheral: CBPeripheral,
        advertisementData: [String: Any],
        rssi RSSI: NSNumber
    ) {
        print(peripheral)
        if self.deviceList.filter({ $0.identifier.uuidString == peripheral.identifier.uuidString}).count == 0 {
            if peripheral.name != nil {
                self.deviceList.append(peripheral)
            }
            if let refreshDeviceList = self.refreshDeviceList {
                refreshDeviceList(self.deviceList)
            }
        }
    }

    // Tells the delegate that peripheral service discovery succeeded.
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error = error {
            print("!!!--- error in didDiscoverServString(describing: ices: \(error.localizedDescription))")
        } else {
            if let cbServiceArray = peripheral.services {
                cbServiceArray.forEach({ peripheral.discoverCharacteristics(nil, for: $0) })
            }
        }
    }

    // Confirm we've discovered characteristics
    // of interest within services of interest
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let error = error {
            print("!!!--- error in didDiscoverCharacteristicString(describing: sFor: \(error.localizedDescription))")
        } else {

            switch service.uuid {
            case CBUUID(string: hrmHeartRateServiceUUID):
                self.hrmHeartRateServices(service: service, peripheral: peripheral)
            case CBUUID(string: hrmBatteryServiceUUID):
                self.hrmBatteryServices(service: service, peripheral: peripheral)
            default:
                print("serviceUuid: \(service.uuid)")
            }
        }
    }

    // We're notified whenever a characteristic
    // value updates regularly or posts once; read and
    // decipher the characteristic value(s) that we've
    // subscribed to
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {

        guard error == nil else {
            return
        }
        switch characteristic.uuid.uuidString {
        case hearRateMeasurement:
            // we generally have to decode BLE
            // data into human readable format
            let heartRate = self.deviceBeatsPerMinute(using: characteristic)
            if let updateHeartBeat = self.updateHeartBeat {
                updateHeartBeat("\(heartRate)")
            }
            print("bpm :\(heartRate)")
        case batteryLevelUUID:
            // we generally have to decode BLE
            // data into human readable format
            self.batteryLevel(characteristic: characteristic)
        case bodySensorLocation:
            // we generally have to decode BLE
            // data into human readable format
            self.sensorLocation = self.readSensorLocation(using: characteristic)
        default:
            print("Default")
        }
    }

    /// To find sensor heartbeat characteristic
    /// - Parameters:
    ///   - service: A collection of data and associated behaviors for accomplishing a function or feature of a device.
    ///   - peripheral: A remote peripheral device.
    func hrmHeartRateServices(service: CBService, peripheral: CBPeripheral) {
        if let characteristics = service.characteristics {
            characteristics.forEach({
                switch $0.uuid.uuidString {
                case hearRateMeasurement:
                    peripheral.setNotifyValue(true, for: $0)
                case bodySensorLocation:
                    // Read body sensor location
                    print("Found a Body Sensor Location Characteristic")
                    peripheral.readValue(for: $0)

                case manufactureNameString:
                    // Read manufacturer name
                    print("Found a HRM manufacturer name Characteristic")
                    peripheral.readValue(for: $0)

                case hearRateServiceUUID:
                    // Write heart rate control point
                    print("Found a Heart Rate Control Point Characteristic")
                    var rawArray: [UInt8] = [0x01]
                    let data = NSData(bytes: &rawArray, length: rawArray.count)
                    peripheral.writeValue(data as Data, for: $0, type: CBCharacteristicWriteType.withoutResponse)
                default:
                    print("Default")
                }
            })
        }
    }

    /// To find sensor battery characteristic
    /// - Parameters:
    ///   - service: A collection of data and associated behaviors for accomplishing a function or feature of a device.
    ///   - peripheral: A remote peripheral device.
    func hrmBatteryServices(service: CBService, peripheral: CBPeripheral) {
        if let characteristics = service.characteristics {
            characteristics.forEach({
                switch $0.uuid.uuidString {
                case batteryLevelUUID:
                    print("Battery Level characteristics")
                    peripheral.readValue(for: $0)
                default:
                    print("Default...")
                }
            })
        }
    }

    /// Find battery level
    /// - Parameter characteristic: A characteristic of a remote peripheral’s service.
    func batteryLevel(characteristic: CBCharacteristic) {

        guard let characteristicData = characteristic.value else { return }
        let valueInUInt8 = [UInt8](characteristicData)
        let batteryBitPattern = Int32(bitPattern: UInt32(valueInUInt8[0]))
        let batteryLevel = Int(batteryBitPattern)
        print("batteryPercentage: \(batteryLevel)")
        self.batteryPercentage = batteryLevel
    }

    /// Read sensor location
    /// - Parameter sensorLocationCharacteristic: A characteristic of a remote peripheral’s service.
    func readSensorLocation(using sensorLocationCharacteristic: CBCharacteristic) -> String {

        if let sensorLocationValue = sensorLocationCharacteristic.value {
            // convert to an array of unsigned 8-bit integers
            let buffer = [UInt8](sensorLocationValue)
            var sensorLocation = ""

            // look at just 8 bits
            if buffer[0] == 1 {
                sensorLocation = "Chest"
            } else if buffer[0] == 2 {
                sensorLocation = "Wrist"
            } else {
                sensorLocation = "N/A"
            }

            return sensorLocation
        }

        return "No value"
    }

    /// Device beats per minute
    /// - Parameter heartRateMeasurementCharacteristic: A characteristic of a remote peripheral’s service.
    func deviceBeatsPerMinute(using heartRateMeasurementCharacteristic: CBCharacteristic) -> Int {

        if let heartRateValue = heartRateMeasurementCharacteristic.value {
            // convert to an array of unsigned 8-bit integers
            let buffer = [UInt8](heartRateValue)

            if (buffer[0] & 0x01) == 0 {
                print("BPM is UInt8")
                return Int(buffer[1])
            } else {
                print("BPM is UInt16")
                return -1
            }
        }
        return -1
    }
}
