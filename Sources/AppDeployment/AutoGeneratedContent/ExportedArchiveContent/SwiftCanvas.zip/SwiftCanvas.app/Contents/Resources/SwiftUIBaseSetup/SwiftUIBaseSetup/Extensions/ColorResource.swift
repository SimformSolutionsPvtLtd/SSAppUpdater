import RswiftResources
import SwiftUI

// MARK: getColor
extension RswiftResources.ColorResource {
    var color: Color {
        Color(name)
    }
}
