import Foundation

enum Dimension {
    case width
    case height
}
