import UIKit

extension CGFloat {
    var adaptedFontSize: CGFloat {
        adapted(dimensionSize: self, to: dimension)
    }

    func adaptedFrame(_ dimension: Dimension) -> CGFloat {
        return adapted(dimensionSize: self, to: dimension)
    }
}
