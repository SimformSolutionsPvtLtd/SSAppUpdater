import Foundation

struct CustomError: Error, Equatable {
    let title: String
    let body: String

    // No internet error
    static let noInternet = CustomError(title: AppStrings.internetConnectionError(),
                                          body: AppStrings.connectToInternet())

    /// Generic error object
    static let genericError = CustomError(title: AppStrings.error(),
                                          body: AppStrings.somethingWentWrong())
}