//
//  KeychainStorageContainer.swift
//  BopilerplateExample
//
//  Created by Purva Rupareliya on 17/04/24.
//

import Foundation

#warning("A static variables class for all your Keychain keys.")
class KeychainStorageContainer {
    @KeyChainWrapper(
        key: KCSettings.Device.apiToken.key,
        defaultValue: KCSettings.Device.apiToken.defaultValue)
    static var apiToken: String?
}
