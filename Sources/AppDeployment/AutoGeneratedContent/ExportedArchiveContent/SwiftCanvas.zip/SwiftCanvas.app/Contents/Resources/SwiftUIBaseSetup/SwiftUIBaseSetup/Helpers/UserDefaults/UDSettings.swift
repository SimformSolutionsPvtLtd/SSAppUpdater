import Foundation

#warning("Add your userdefaults keys and default values here.")
enum UDSettings {
//    enum User {
//        static var userId = ASSettingItem(key: "user-id", defaultValue: "")
        #warning("This is codable declaration for reference")
//        static var userModel = ASSettingItem<UserModel>(key: "user-model", defaultValue: UserModel())
//    }
}

// Temporary: Model to show the usage
/* struct UserModel: Codable {
}*/
