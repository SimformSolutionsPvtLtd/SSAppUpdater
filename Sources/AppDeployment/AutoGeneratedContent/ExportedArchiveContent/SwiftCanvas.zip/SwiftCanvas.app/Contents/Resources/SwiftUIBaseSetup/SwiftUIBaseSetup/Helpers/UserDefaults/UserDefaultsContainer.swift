import Foundation

#warning("A static variables class for all your UserDefaults keys.")
class AppStorageContainer {
#warning("This reference shows its usage")
//    @UserDefault(
//        key: UDSettings.User.userId.key,
//        defaultValue: UDSettings.User.userId.defaultValue)
//    static var userId: String

//    @UserDefault(
//        key: UDSettings.User.userModel.key,
//        defaultValue: UDSettings.User.userModel.defaultValue)
//    static var userModel: UserModel
}
