import Foundation

/// Server error model
/// This model is used when server sends custom error in response from server side
class ServerErrorModel: Codable {
    let error: String
    let code: Int?
}
