import Foundation

#warning("Replace it with your formData attachment model")
struct AttachmentFormData {
    let key: String
    let fileData: Data
    let fileName: String
    let mimeType: String
}
