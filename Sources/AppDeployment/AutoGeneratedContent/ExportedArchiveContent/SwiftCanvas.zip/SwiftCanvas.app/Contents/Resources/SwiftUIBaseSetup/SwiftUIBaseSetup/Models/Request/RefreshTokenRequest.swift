import Foundation

#warning("Replace it with your requestToken request model")
public struct RefreshTokenRequest: Codable {
    let token: String
    let refreshToken: String
}