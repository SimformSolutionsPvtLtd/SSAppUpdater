import Foundation

#warning("Replace it with your BaseResponse model")
struct BaseResponseModel<T: Codable>: Codable {
    let result: T?
    let status: Bool
    let message: String
    let statusCode: Int
}
