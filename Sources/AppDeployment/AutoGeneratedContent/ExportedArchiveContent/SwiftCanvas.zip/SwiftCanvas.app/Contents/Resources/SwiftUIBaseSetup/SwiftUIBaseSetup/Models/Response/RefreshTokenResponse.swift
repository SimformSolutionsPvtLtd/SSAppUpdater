import Foundation

#warning("Replace it with your refreshToken response model")
struct RefreshTokenResponse: Codable {
    let apiRefreshToken, token: String
    let userID: Int

    enum CodingKeys: String, CodingKey {
        case apiRefreshToken, token
        case userID = "userId"
    }
}
