import Foundation

/// The user list request model
public struct UserListRequest: Codable {
    let size: Int
}
