class NetworkHelper {
    static var httpPreTokenHeader: [String: String] {
        return [Constants.HeaderKeys.contentType: "application/json"]
    }

    static var httpPreAuthTokenHeader: [String: String] {
        return [Constants.HeaderKeys.contentType: "application/json", "Authorization": "Bearer \(KeychainStorageContainer.apiToken ?? "")"]
    }

    static var multipartFormRequestHeaders: [String: String] {
        return [Constants.HeaderKeys.contentType: "multipart/form-data", "Authorization": "Bearer \(KeychainStorageContainer.apiToken ?? "")"]
    }
}
