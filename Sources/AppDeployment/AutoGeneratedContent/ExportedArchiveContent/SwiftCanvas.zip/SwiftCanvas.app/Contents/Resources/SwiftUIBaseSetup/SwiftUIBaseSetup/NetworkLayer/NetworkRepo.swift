import NetworkEngine

/// Defines the available network calls with their input types
protocol NetworkRepo: TargetType & NetworkRequestable {
    static func refreshToken(request: RefreshTokenRequest) -> Self
    static func randomUser(request: UserListRequest) -> Self
}
