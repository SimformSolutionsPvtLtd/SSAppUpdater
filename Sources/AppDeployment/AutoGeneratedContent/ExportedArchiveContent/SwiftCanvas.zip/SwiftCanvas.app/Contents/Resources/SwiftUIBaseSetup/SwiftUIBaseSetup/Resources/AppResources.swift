import Foundation

let AppStrings = R.string.localizable
let AppColors = R.color
