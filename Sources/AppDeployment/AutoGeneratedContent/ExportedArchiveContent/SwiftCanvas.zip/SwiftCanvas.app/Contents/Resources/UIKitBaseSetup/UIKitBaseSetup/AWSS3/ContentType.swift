
import Foundation

/// Content types for the file uploading
struct ContentType {
    static let image = "image/png"
}
