
import Foundation
import AWSS3
import AWSCore

/// Class responsible for S3 bucket management
class S3Manager {

    static let shared = S3Manager()
    private let imageCache = NSCache<NSString, UIImage>()

    /// Upload the image to S3 bucket
    /// - Parameters:
    ///   - imgName: Image name
    ///   - bucketName: bucket name
    ///   - folderName: folder name
    ///   - image: The image to upload
    ///   - completion: The completion handler to be called with success message or `CustomError`
    func uploadImageInS3(imgName: String,
                         bucketName: String,
                         folderName: AWSFolderName,
                         image: UIImage,
                         completion: @escaping (Swift.Result<String, CustomError>) -> Void) {
        guard let resizedImg = image.resizeImage() else {
            completion(.failure(CustomError(title: AppStrings.appName(),
                                            body: AppStrings.imageNotFound())))
            return
        }
        // create a local image that we can use to upload to s3
        let tempUrlstr: String = NSTemporaryDirectory()
        guard let tempUrl: URL = URL(string: tempUrlstr) else {
            completion(.failure(CustomError(title: AppStrings.appName(),
                                            body: AppStrings.urlNotFound())))
            return
        }
        let path: String  = tempUrl.appendingPathComponent(imgName).path
        guard let imageData: Data = resizedImg.jpegData(compressionQuality: 0.4) else {
            completion(.failure(CustomError(title: AppStrings.appName(),
                                            body: AppStrings.imageNotFound())))
            return
        }
        try? imageData.write(to: URL(fileURLWithPath: path), options: [.atomic])
        // once the image is saved we can use the path to create a local fileurl
        let url: URL = URL(fileURLWithPath: path)
        let expression = AWSS3TransferUtilityUploadExpression()
        expression.setValue("public-read", forRequestHeader: "x-amz-acl")
        expression.progressBlock = { (task, progress) in
            print(progress)
        }
        let completionHandler: AWSS3TransferUtilityUploadCompletionHandlerBlock? = { (task, error) in
            if let error = error {
                completion(.failure(CustomError(title: AppStrings.appName(),
                                                body: error.localizedDescription)))
            } else {
                let imageKey = Constants.URL.awsURL + bucketName + "/" + folderName.rawValue + "/" + imgName
                completion(.success(imageKey))
            }
        }
        /// AWSS3TransferUtility
        let transferTransferUtility: AWSS3TransferUtility = AWSS3TransferUtility.default()
        transferTransferUtility.uploadFile(url,
                                           bucket: bucketName,
                                           key: folderName.rawValue + "/" + imgName,
                                           contentType: ContentType.image,
                                           expression: expression,
                                           completionHandler: completionHandler)
    }

    /// Download image from S3 bucket
    /// - Parameters:
    ///   - imgName: The name of the image
    ///   - bucketName: bucket name
    ///   - folderName: folder name
    ///   - completion: completion handler that will be fired with result `UIImage` or `CustomError`
    func downloadFromS3(imgName: String,
                        bucketName: String,
                        folderName: AWSFolderName,
                        completion: @escaping (Swift.Result<UIImage, CustomError>) -> Void) {
        if let cachedImage = imageCache.object(forKey: imgName as NSString) {
            completion(.success(cachedImage))
        } else {
            var completionHandler: AWSS3TransferUtilityDownloadCompletionHandlerBlock?
            let expression = AWSS3TransferUtilityDownloadExpression()
            expression.setValue("public-read", forRequestHeader: "x-amz-acl")
            expression.progressBlock = { (task, progress) in
                print(progress)
            }
            completionHandler = { (task, location, data, error) in
                DispatchQueue.main.async { [weak self] in
                    guard let uSelf = self else {
                        return
                    }
                    if let error = error {
                        completion(.failure(CustomError(title: AppStrings.appName(),
                                                        body: error.localizedDescription)))
                    } else {
                        if let data = data, let image = UIImage(data: data) {
                            uSelf.imageCache.setObject(image, forKey: imgName as NSString)
                            completion(.success(image))
                            print(image)
                        }
                    }
                }
            }
            let transferUtility = AWSS3TransferUtility.default()
            transferUtility.downloadData(fromBucket: bucketName,
                                         key: "\(folderName.rawValue)/\(imgName)",
                                         expression: expression,
                                         completionHandler: completionHandler)
        }
    }
}
