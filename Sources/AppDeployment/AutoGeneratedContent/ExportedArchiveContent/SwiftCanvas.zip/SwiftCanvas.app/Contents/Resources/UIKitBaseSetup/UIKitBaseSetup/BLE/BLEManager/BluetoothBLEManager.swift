
import UIKit
import CoreBluetooth
import CoreLocation

/// PermissionErrorString : provide permission error string for SDK
struct PermissionErrorString {
    static var ifAuthorizedButTurnOff = "Turn On Bluetooth to Allow \"APP\" to connect to Accessories"
    static var ifPermissionDenied = "Allow Bluetooth permission to Allow \"APP\" to connect to Accessories"
    static var ifLocationPermissionDenied = "Allow Location permission to Allow \"APP\" to detect beacons"
    static var ifNotificationPermissionDenied = "Allow Notification permission to Allow \"APP\" to send notifications"
}

/// BeaconConfig: content beacon configuration
public struct BeaconConfig {
    var uuid: String = ""
    var identifier = ""
}

/// FilterBeacon: beacon with custom values
public struct FilterBeacon {
    public var beacon: CLBeacon
    public var rssi: Double
    public var distance: Double
    func beaconKey() -> String { return "\(beacon.uuid.uuidString):\(beacon.major):\(beacon.minor)" }
}

/// SearchType:  To provide active passive search
public struct SearchType {
    var isActiveSearch: Bool
    var falseAttempted: Int
    var currentTimerValue: Int
    var lastRegionEnterTime: Int64
}

let bleManager = BluetoothBLEManager.shared

class BluetoothBLEManager: NSObject {
    
    /// Shared variable
    public static let shared = BluetoothBLEManager()

    /// Variable
    private var bluetoothManager: CBPeripheralManager?
    private var closestBeacon: FilterBeacon?
    private var backgroundTask: UIBackgroundTaskIdentifier?
    private let opts = [CBCentralManagerOptionShowPowerAlertKey: true]
    private var beaconConfig: BeaconConfig?
    private var latestBeacons = [[CLBeacon]]()
    private var search = SearchType(
        isActiveSearch: true,
        falseAttempted: 0,
        currentTimerValue: 5,
        lastRegionEnterTime: Date().toMilliseconds()
    )
    private var timer: Timer?
    private let maxAttempted: Int = 3
    private let maxActiveAttempted: Int = 60
    private let activeSearch: Int = 5
    private let passiveSearch: Int = 10
    private var exitCounter: Int = 0
    private let dispatchGroup = DispatchGroup()
    private let entryBeaconDistance = 5.0
    private let exitBeaconDistance = 10.0
    private var connectedBeacon: Bool = false

    /// LocationBlockType
    /// - Parameters:
    ///   - location: current location
    ///   - error: error
    public typealias LocationBlockType = (_ location: CLLocation?, _ error: Error?) -> Void

    /// BeaconBlockType:
    /// - Parameters:
    ///   - FilterBeacon: current beacon
    ///   - CLLocationCoordinate2D: location coordinate
    public typealias BeaconBlockType = (_ beacon: FilterBeacon, _ location: CLLocationCoordinate2D?) -> Void

    /// RangedBeacons:
    /// - Parameters:
    ///   - beacons: available beacons
    public typealias RangedBeacons = (_ beacons: [FilterBeacon]) -> Void

    /// Permission:
    /// - Parameters:
    ///   - message: error message
    ///   - success: true/false
    public typealias Permission = (_ message: String, _ success: Bool) -> Void

    /// LocationCheckLiveData:
    /// - Parameters:
    ///   - location: location coordinate
    public typealias LocationCheckLiveData = (_ location: CLLocationCoordinate2D?) -> Void

    /// OnScanStopped:
    public typealias OnScanStopped = () -> Void

    /// locationMonitorBlock: To get current location
    open var locationMonitorBlock: LocationBlockType?

    /// locationManager: location manager
    open var locationManager: CLLocationManager?

    /// onBeaconCamped: Call when beacon in range
    open var onBeaconCamped: BeaconBlockType?

    /// onBeaconExit: Call when beacon out of range
    open var onBeaconExit: BeaconBlockType?

    /// onRangedBeacon: Call to get all beacon
    open var onRangedBeacon: RangedBeacons?

    /// onPermissionChange; Call when user change current permission
    open var onPermissionChange: Permission?

    /// onScanStopped: Call when SDK stop scanning
    open var onScanStopped: OnScanStopped?

    /// locationCheckLiveData: to get location when SDK search for location based rule
    open var locationCheckLiveData: LocationCheckLiveData?

    /// isScanOnGoing: indicate scan is progress or not
    open var isScanOnGoing: Bool = false

    /// txPower: To calculate the distance of beacon to device
    open var txPower: Double {
        get {
            return bleUserManager.txPower
        }
        set (newValue) {
            bleUserManager.txPower = newValue < 0 ? newValue : bleUserManager.txPower
        }
    }

    /// isBackgroundMode: SDK scan beacon in background true/false
    open var isBackgroundMode: Bool {
        get {
            return bleUserManager.isBackgroundEnabled
        }
        set(newValue) {
            bleUserManager.isBackgroundEnabled = newValue
        }
    }

    override init() {
        super.init()
        bleManager.setObserver()
    }

    /// start: Start the near by beacon scanning
    /// - Parameter permissionBlock: Execute when SDK don't have permission
    open func start(permissionBlock: @escaping Permission, uuid: String, identifier: String = "") {

        if let permission = bleManager.locationPermission() {
            if !permission {
                permissionBlock(PermissionErrorString.ifLocationPermissionDenied, false)
            } else {
                permissionBlock("Done", true)
                DispatchQueue.main.async {
                    bleManager.isScanOnGoing = true
                    bleManager.initLocationManager()
                    let config = BeaconConfig(uuid: uuid, identifier: "")
                    bleManager.beaconConfig = config
                    bleManager.addBeaconForMonitoring(beacon: config)
                }
            }
        } else {
            permissionBlock("", false)
        }
    }

    /// Add beacon for monitoring
    ///
    /// - Parameter beacon: beacon config
    public func addBeaconForMonitoring(beacon: BeaconConfig) {
        if let uID = UUID(uuidString: beacon.uuid) {
            let beaconRegion = CLBeaconRegion(
                beaconIdentityConstraint: CLBeaconIdentityConstraint(uuid: uID),
                identifier: beacon.identifier
            )
            beaconRegion.notifyOnEntry = true
            beaconRegion.notifyOnExit = true
            bleManager.locationManager?.allowsBackgroundLocationUpdates = true
            bleManager.locationManager?.pausesLocationUpdatesAutomatically = false
            bleManager.locationManager?.startMonitoring(for: beaconRegion)
            bleManager.locationManager?.desiredAccuracy = kCLLocationAccuracyBest
            bleManager.locationManager?.startUpdatingLocation()
            bleManager.locationManager?.startMonitoringVisits()
            bleManager.locationManager?.startUpdatingHeading()
            bleManager.locationManager?.distanceFilter = kCLLocationAccuracyBest
            bleManager.locationManager?.startRangingBeacons(satisfying: beaconRegion.beaconIdentityConstraint)
            bleManager.bluetoothManager = CBPeripheralManager(delegate: bleManager, queue: nil)
        } else {
            print("UUID is not correct")
        }
    }

    /// GetAllBeacons
    /// - Parameter beacons: beacons
    func getAllBeacons(beacons: [[CLBeacon]]) -> [FilterBeacon] {
        let allBeacons = beacons.flatMap({ $0 })
        var uniqueBeacons = [CLBeacon]()
        var similarBeacons = [Int: [CLBeacon]]()
        var kalmanBeacons = [FilterBeacon]()

        allBeacons.forEach { beacon in
            if uniqueBeacons.filter({ $0.major == beacon.major && $0.minor == beacon.minor }).count == 0 {
                uniqueBeacons.append(beacon)
            }

            if let index = uniqueBeacons.firstIndex(where: { $0.major == beacon.major && $0.minor == beacon.minor }) {
                var beaconArray = [CLBeacon]()
                if let array = similarBeacons[index] {
                    beaconArray.append(contentsOf: array)
                    beaconArray.append(beacon)
                    similarBeacons[index] = beaconArray
                } else {
                    beaconArray.append(beacon)
                    similarBeacons[index] = beaconArray
                }
            }
        }
        uniqueBeacons.forEach { (beacon) in
            if let index = uniqueBeacons.firstIndex(of: beacon) {
                if let array = similarBeacons[index] {
                    let accuracyArray = array.map({ $0.rssi })
                    var filter = KalmanFilter(stateEstimatePrior: 0.0, errorCovariancePrior: 1)
                    for accuracy in accuracyArray {
                        let prediction = filter.predict(stateTransitionModel: 1,
                                                        controlInputModel: 0,
                                                        controlVector: 0,
                                                        covarianceOfProcessNoise: 0)
                        let update = prediction.update(measurement: Double(accuracy),
                                                       observationModel: 1,
                                                       covarienceOfObservationNoise: 0.1)
                        filter = update
                    }
                    kalmanBeacons.append(
                        FilterBeacon(beacon: beacon,
                                     rssi: filter.stateEstimatePrior,
                                     distance: bleManager.getDistance(rssi: filter.stateEstimatePrior))
                    )
                }
            }
        }
        return kalmanBeacons
    }

    /// Get distance based on tx-power
    /// - Parameter rssi: beacon rssi
    /// - Returns: The distance
    func getDistance(rssi: Double) -> Double {
        let powValue = rssi.roundToDecimal(2) / bleManager.txPower
        return (((0.89976) * pow(powValue, 7.7095)) + 0.111).roundToDecimal(2)
    }

    /// SwitchActiveToPassiveSearch: Switch active to passive search
    func switchActiveToPassiveSearch() {
        let attempted = bleManager.search.falseAttempted >= maxActiveAttempted
        bleManager.search.isActiveSearch = !attempted
        bleManager.search.falseAttempted = !attempted ? bleManager.search.falseAttempted : maxAttempted
        bleManager.updateTimer()
    }

    /// UpdateTimer: Update timer while switching active to passive or passive to active
    func updateTimer() {
        if bleManager.search.isActiveSearch,
           bleManager.search.currentTimerValue != activeSearch {
            bleManager.search.lastRegionEnterTime = Date().toMilliseconds()
            bleManager.timer?.invalidate()
            bleManager.timer = Timer.scheduledTimer(timeInterval: TimeInterval(activeSearch),
                                                    target: bleManager,
                                                    selector: #selector(getClosestBeaconAfterSomeTime),
                                                    userInfo: nil,
                                                    repeats: true)
        } else if !(bleManager.search.isActiveSearch),
                  bleManager.search.currentTimerValue != passiveSearch {
            bleManager.timer?.invalidate()
            bleManager.timer = Timer.scheduledTimer(timeInterval: TimeInterval(passiveSearch),
                                                    target: bleManager,
                                                    selector: #selector(getClosestBeaconAfterSomeTime),
                                                    userInfo: nil,
                                                    repeats: true)
        }
    }

    /// Entry beacon
    /// - Parameter beacon: beacons that are in range
    func entryBeacon(beacon: FilterBeacon) {
        bleManager.closestBeacon = beacon
        bleManager.onBeaconCamped?(beacon, bleManager.locationManager?.location?.coordinate)
    }

    /// Exit beacon
    /// - Parameter beacon: exited beacon
    func exitBeacon(beacon: FilterBeacon) {
        bleManager.exitCounter = 0
        bleManager.onBeaconExit?(beacon, bleManager.locationManager?.location?.coordinate)
        bleManager.closestBeacon = nil
    }
}

// MARK: - Private methods
extension BluetoothBLEManager {

    /// initLocationManager
    /// - Parameter enableTimer: true if timer needs to be set, false otherwise
    private func initLocationManager(enableTimer: Bool = true) {
        bleManager.locationManager?.delegate = bleManager
        bleManager.locationManager?.startMonitoringVisits()
        bleManager.locationManager?.desiredAccuracy = kCLLocationAccuracyBest
        timer = Timer.scheduledTimer(timeInterval: TimeInterval(activeSearch),
                                     target: bleManager,
                                     selector: #selector(bleManager.getClosestBeaconAfterSomeTime),
                                     userInfo: nil,
                                     repeats: true)
        if enableTimer {
            bleManager.timer = timer
        }
    }

    /// Set Observer: Set observer for application modes like enter background
    private func setObserver() {
        // applicationDidEnterBackground
        NotificationCenter.default.removeObserver(BluetoothBLEManager.self,
                                                  name: UIApplication.didEnterBackgroundNotification,
                                                  object: nil)
        NotificationCenter.default.addObserver(BluetoothBLEManager.self,
                                               selector: #selector(applicationDidEnterBackground),
                                               name: UIApplication.didEnterBackgroundNotification,
                                               object: nil)
        // applicationWillTerminate
        NotificationCenter.default.removeObserver(BluetoothBLEManager.self,
                                                  name: UIApplication.didEnterBackgroundNotification,
                                                  object: nil)
        NotificationCenter.default.addObserver(BluetoothBLEManager.self,
                                               selector: #selector(applicationWillTerminate),
                                               name: UIApplication.willTerminateNotification,
                                               object: nil)
        // applicationWillEnterForegroundNotification
        NotificationCenter.default.removeObserver(BluetoothBLEManager.self,
                                                  name: UIApplication.willEnterForegroundNotification,
                                                  object: nil)
        NotificationCenter.default.addObserver(BluetoothBLEManager.self,
                                               selector: #selector(applicationWillEnterForeground),
                                               name: UIApplication.willEnterForegroundNotification,
                                               object: nil)
    }

    /// DeterminedBeacons: Calculate closest beacon from the detected list
    ///
    /// - Parameters:
    ///   - beacons: List of beacon
    ///   - isAppActive: To check app is foreground or background
    private func determinedBeacons(kalmanBeacons: [FilterBeacon], isAppActive: Bool) {
        let newClosestBeacon = kalmanBeacons.sorted(by: { $0.rssi > $1.rssi }).first
        bleManager.onRangedBeacon?(kalmanBeacons)
        if bleManager.closestBeacon == nil {
            if let newClosestBeacon = newClosestBeacon, newClosestBeacon.distance <= entryBeaconDistance {
                bleManager.entryBeacon(beacon: newClosestBeacon)
                return
            } else if !(newClosestBeacon?.distance ?? 0 >= 5.0) || newClosestBeacon == nil {
                return
            }
            bleManager.exitCounter = 0
        } else {
            let exitingBeacon = kalmanBeacons.filter {
                $0.beacon.uuid == bleManager.closestBeacon?.beacon.uuid &&
                $0.beacon.major == bleManager.closestBeacon?.beacon.major &&
                $0.beacon.minor == bleManager.closestBeacon?.beacon.minor
            }
            if !(exitingBeacon.count > 0) {
                bleManager.exitCounter += 1
                if bleManager.exitCounter >= bleManager.maxAttempted {
                    guard let closestBeacon = bleManager.closestBeacon else {
                        return
                    }
                    bleManager.exitBeacon(beacon: closestBeacon)
                    return
                }
            }

            if let rangeInBeacon = exitingBeacon.first, rangeInBeacon.distance >= exitBeaconDistance {
                guard let closestBeacon = bleManager.closestBeacon else {
                    return
                }
                bleManager.exitBeacon(beacon: closestBeacon)
                return
            }

            if let closestBeacon = bleManager.closestBeacon,
               let newClosestBeacon = newClosestBeacon,
               closestBeacon.beacon.major == newClosestBeacon.beacon.major,
               closestBeacon.beacon.minor == newClosestBeacon.beacon.minor {
                bleManager.closestBeacon = newClosestBeacon
            } else {
                if let closestBeacon = bleManager.closestBeacon, let newClosestBeacon = newClosestBeacon {
                    bleManager.exitBeacon(beacon: closestBeacon)
                    DispatchQueue.delay(bySeconds: 2.0) {
                        bleManager.entryBeacon(beacon: newClosestBeacon)
                    }
                }
            }
        }
    }

    /// Open settings
    /// - Parameter message: Descriptive text that provides additional details about the reason for the alert.
    private func openSettings(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        let settingAction = UIAlertAction(title: "Setting", style: .default) { _ in
            guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                return
            }
            if UIApplication.shared.canOpenURL(settingsUrl) {
                UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                    print("Settings opened: \(success)")
                })
            }
        }
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alert.addAction(cancelAction)
        alert.addAction(settingAction)
        UIApplication.shared.keyWindow?.rootViewController?.present(
            alert,
            animated: true,
            completion: nil
        )
    }

    /// Get near by beacon based on active passive search
    @objc private func getClosestBeaconAfterSomeTime() {
        if bleManager.latestBeacons.count > 0 {
            bleManager.search.isActiveSearch = true
            bleManager.search.falseAttempted = 0
            var copyBeacons = [[CLBeacon]]()
            copyBeacons.append(contentsOf: bleManager.latestBeacons)
            bleManager.latestBeacons.removeAll()
            bleManager.determinedBeacons(kalmanBeacons: bleManager.getAllBeacons(beacons: copyBeacons),
                                         isAppActive: UIApplication.shared.applicationState == .active)
        } else {
            bleManager.search.falseAttempted += 1
            bleManager.connectedBeacon = false
            bleManager.determinedBeacons(kalmanBeacons: [],
                                         isAppActive: UIApplication.shared.applicationState == .active)
        }
        bleManager.switchActiveToPassiveSearch()
    }
}

// MARK: - Get beacon in background
extension BluetoothBLEManager {

    /// Call when Application enters in background
    @objc func applicationDidEnterBackground() {
        if bleManager.isBackgroundMode {
            let application = UIApplication.shared
            bleManager.backgroundTask = application.beginBackgroundTask(expirationHandler: {
                if let backgroundTask = bleManager.backgroundTask {
                    application.endBackgroundTask(backgroundTask)
                    bleManager.backgroundTask = UIBackgroundTaskIdentifier.invalid
                }
            })
        }
    }

    /// Call when user terminate the app
    @objc func applicationWillTerminate() {
        let application = UIApplication.shared
        bleManager.backgroundTask = application.beginBackgroundTask(expirationHandler: {
            if let bgT = bleManager.backgroundTask {
                application.endBackgroundTask(bgT)
                bleManager.backgroundTask = UIBackgroundTaskIdentifier.invalid
            }

        })
    }

    /// Call when application enter in foreground
    @objc func applicationWillEnterForeground() {
        if !(BluetoothBLEManager.shared.locationPermission() ?? true) {
            BluetoothBLEManager.shared.onPermissionChange?(PermissionErrorString.ifLocationPermissionDenied, false)
        }
    }
}

// MARK: - Permission
extension BluetoothBLEManager {
    
    /// Get location permission status
    /// - Returns: true if location permission is either `CLAuthorizationStatus.authorizedAlways` or
    ///            `CLAuthorizationStatus.authorizedWhenInUse`, otherwise false
    public func locationPermission() -> Bool? {
        let authorizationStatus: CLAuthorizationStatus

        if #available(iOS 14, *) {
            authorizationStatus = locationManager?.authorizationStatus ?? .notDetermined
        } else {
            authorizationStatus = CLLocationManager.authorizationStatus()
        }

        // check the permission status
        switch authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            return true
        // get the user location
        case .restricted, .denied:
            // redirect the users to settings
            return false
        default:
            let manager = BluetoothBLEManager.shared
            manager.locationManager?.delegate = manager
            manager.locationManager?.requestAlwaysAuthorization()
            return nil
        }
    }
}

// MARK: - CLLocationManagerDelegate
extension BluetoothBLEManager: CLLocationManagerDelegate {

    /// locationManager:didUpdateLocations:
    ///    Invoked when new locations are available.  Required for delivery of
    ///    deferred locations.  If implemented, updates will
    ///    not be delivered to locationManager:didUpdateToLocation:fromLocation:
    ///
    /// - Parameters:
    ///   - manager: The location manager object that generated the update event.
    ///   - locations: locations is an array of CLLocation objects in chronological order.
    public func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        locationMonitorBlock?(locations.first, nil)
    }

    /// Invoked when an error has occurred. Error types are defined in "CLError.h".
    ///
    /// - Parameters:
    ///   - manager: The location manager object that generated the update event.
    ///   - error: The error object containing the reason the location or heading could not be retrieved
    public func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        locationMonitorBlock?(nil, error)
    }

    /// Tells the delegate that one or more beacons are in range.
    ///
    /// - Parameters:
    ///   - manager: The location manager object that generated the update event.
    ///   - beacons: An array of CLBeacon objects representing the beacons currently in range.
    ///   If beacons is empty, you can assume that no beacons matching the specified region are in range.
    ///   When a specific beacon is no longer in beacons, that beacon is no longer received by the device.
    ///   You can use the information in the CLBeacon objects to determine the range of each beacon and its identifying information.
    ///   - region: The region object containing the parameters that were used to locate the beacons
    public func locationManager(
        _ manager: CLLocationManager,
        didRangeBeacons beacons: [CLBeacon],
        in region: CLBeaconRegion
    ) {
        let filteredBeacons = beacons.filter({ $0.rssi < 0})
        BluetoothBLEManager.shared.latestBeacons.append(filteredBeacons)
    }

    /// Tells the delegate that the user entered the specified region.
    ///
    /// - Parameters:
    ///   - manager: The location manager object reporting the event
    ///   - region: The region object containing the parameters that were used to locate the beacons
    public func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        if let beaconRegion = region as? CLBeaconRegion {
            manager.startRangingBeacons(satisfying: beaconRegion.beaconIdentityConstraint)
        }
        BluetoothBLEManager.shared.connectedBeacon = true
    }

    /// Tells the delegate that the user left the specified region.
    ///
    /// - Parameters:
    ///   - manager: The location manager object reporting the event
    ///   - region: The region object containing the parameters that were used to locate the beacons
    public func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        if let beaconRegion = region as? CLBeaconRegion {
            manager.stopRangingBeacons(satisfying: beaconRegion.beaconIdentityConstraint)
        }
        BluetoothBLEManager.shared.connectedBeacon = false
    }

    public func locationManager(_ manager: CLLocationManager, didVisit visit: CLVisit) {
        // do nothing
    }
}

// MARK: - CBPeripheralManagerDelegate
extension BluetoothBLEManager: CBPeripheralManagerDelegate {

    /// Invoked when the peripheral manager's state is updated.
    ///
    /// - Parameter peripheral: The peripheral manager whose state has changed
    public func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        switch CBPeripheralManager.authorization {
        case .allowedAlways:
            if peripheral.state == .poweredOff {
                print("power on ----->>")
                self.openSettings(message: PermissionErrorString.ifAuthorizedButTurnOff)
            }
        case .denied:
            self.openSettings(message: PermissionErrorString.ifPermissionDenied)
        case .notDetermined:
            break
        case .restricted:
            break
        @unknown default:
            break
        }
    }
}
