
import UIKit

/// The common behavior can be defined here
/// Every ViewController should inherit this base and common configurations should be accumulated here.
class BaseViewController: UIViewController {

    /// Show simple dialogue
    /// - Parameters:
    ///   - title: The title of dialogue
    ///   - message: The message of dialogue
    ///   - dismissAfter: The time in seconds
    func showDialogue(title: String, message: String = "", dismissAfter: Double = 1) {
        let alertController = UIAlertController.createAlert(title: title,
                                                            message: message)
        self.present(alertController,
                     animated: true) {
            DispatchQueue.main.asyncAfter(deadline: .now() + dismissAfter) { [weak self] in
                self?.dismiss(animated: true, completion: nil)
            }
        }
    }

    deinit {
        print("Deinitialised:- \(self)")
    }
}
