
import Foundation

/// The common behavior can be defined here.
/// Every ViewModel should inherit this base and common configurations should be accumulated here.
class BaseViewModel {
    
    let error: Dynamic<CustomError?> = Dynamic(nil)
    let showLoading: Dynamic<Bool> = Dynamic(false)
}
