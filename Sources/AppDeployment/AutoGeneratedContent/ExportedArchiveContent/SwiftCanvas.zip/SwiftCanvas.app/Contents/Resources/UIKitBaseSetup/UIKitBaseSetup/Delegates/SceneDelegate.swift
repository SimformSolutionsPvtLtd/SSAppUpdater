
import UIKit
import Bagel
import Sentry
import SSAppUpdater

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(
        _ scene: UIScene,
        willConnectTo session: UISceneSession,
        options connectionOptions: UIScene.ConnectionOptions
    ) {
        startSentry()
        startBagel()
        checkInAppUpdate()
    }

    func sceneDidDisconnect(_ scene: UIScene) {
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
    }

    func sceneWillResignActive(_ scene: UIScene) {
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
    }
    
    /// Perform check for the app update
    private func checkInAppUpdate() {
        // Default Example
        SSAppUpdater.shared.performCheck { (versionInfo) in
            // Version Info have all the app update related information
            // Display AppUpdate UI based on versionInfo.isAppUpdateAvailable flag
        }
    }
    
    /// Start the sentry for crash reporting
    private func startSentry() {
        guard !AppSecrets.sentryKey.isEmpty else { fatalError("Sentry Dns key Required") }
        SentrySDK.start { options in
            options.dsn = AppSecrets.sentryKey
            options.debug = true // Helpful to see what's going on
        }
    }
    
    /// Start bagel (Would not start in Production builds)
    private func startBagel() {
        #if Development
        Bagel.start()
        #endif
    }
}
