
/// A wrapper on Type T to bind the listener for value change
class Dynamic<T> {
    
    typealias Listener = (T) -> Void
    
    // MARK: Vars & Lets
    var listener: Listener?
    var value: T {
        didSet {
            self.fire()
        }
    }
    
    // MARK: Initialization
    init(_ value: T) {
        self.value = value
    }

    // MARK: Public methods
    
    /// Bind the listener
    /// - Parameter listener: The `Listener`
    func bind(_ listener: Listener?) {
        self.listener = listener
    }
    
    /// Fire the listener with current value
    internal func fire() {
        self.listener?(value)
    }
}
