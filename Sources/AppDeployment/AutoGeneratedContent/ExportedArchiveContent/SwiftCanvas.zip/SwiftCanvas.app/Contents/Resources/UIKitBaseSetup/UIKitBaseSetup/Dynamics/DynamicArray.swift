
import Foundation

/// Represents the listeners to fire based on Aray operation
enum ListenerToFire {
    case add
    case remove
    case defaults
}

/// Dynamic array to have listeners fired based on array operations
/// The listeners can be set by on of the case of `ListenerToFire`
class DynamicArray<T>: DynamicAsync<[T]> {
    
    typealias RemoveListener = (Int) -> Void
    typealias AddListener = ((Int)) -> Void
    
    // MARK: Vars & Lets
    var removeListener: RemoveListener?
    var appendListener: AddListener?
    var listenerToFire = ListenerToFire.defaults
    
    override func fire() {
        if listenerToFire == .defaults {
            listener?(value)
        }
        self.listenerToFire = .defaults
    }
    
    // MARK: Public methods
    
    /// Append the element
    /// - Parameter element: The element to append
    func append(_ element: T) {
        self.listenerToFire = .add
        self.value.append(contentsOf: [element])
        self.appendListener?(value.count)
    }
    
    /// The array of elemets to append
    /// - Parameter contentsOf: The elements array
    func append(_ contentsOf: [T]) {
        self.listenerToFire = .add
        self.value.append(contentsOf: contentsOf)
        self.appendListener?(contentsOf.count)
    }
    
    /// Remove the element at position passed into parametr `position`
    /// - Parameter position: The index of the element to remove
    func remove(_ position: Int) {
        self.listenerToFire = .remove
        self.value.remove(at: position)
        self.removeListener?(position)
    }
    
    /// Binds the array remove operation listener
    /// - Parameter listener: The `RemoveListener`
    func bindRemoveListener(_ listener: RemoveListener?) {
        self.removeListener = listener
    }
    
    /// Binds the array append operation listener
    /// - Parameter listener: The `AddListener`
    func bindAppendListener(_ listener: AddListener?) {
        self.appendListener = listener
    }
}
