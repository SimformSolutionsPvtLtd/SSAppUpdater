
import Foundation

/// Wrapper using `Dynamic` for dynamic async
class DynamicAsync<T>: Dynamic<T> {

    override init(_ value: T) {
        super.init(value)
    }

    override func fire() {
        self.listener?(self.value)
    }
}

