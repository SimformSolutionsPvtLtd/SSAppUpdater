
import UIKit

extension Array {
    
    /// The second element of the collection.
    ///
    /// If the collection is empty, the value of this property is `nil`.
    ///
    ///     let numbers = [10, 20, 30, 40, 50]
    ///     if let secondNumber = numbers.second{
    ///         print(secondNumber)
    ///     }
    ///     // Prints "20"
    @inlinable public var second: Element? {
            return (self.count > 1) ? self[1] : nil
    }
}
