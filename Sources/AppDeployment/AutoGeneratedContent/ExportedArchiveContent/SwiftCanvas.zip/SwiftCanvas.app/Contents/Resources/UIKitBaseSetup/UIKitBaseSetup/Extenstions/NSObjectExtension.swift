
import Foundation

extension NSObject {
    
    /// Provide class name in string(But class must be alloc first)
    var className: String {
        return String(describing: type(of: self))
    }
    
    /// Provide class name in string
    class var className: String {
        return String(describing: self)
    }
}
