
import UIKit
import SwiftDate

extension String {

    /// Get estimated height of the text
    ///
    /// - Parameters:
    ///   - width: width of the super view
    ///   - font: font with size to get estimated height
    /// - Returns: Estimated height of the text
    func height(withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(
            with: constraintRect,
            options: .usesLineFragmentOrigin,
            attributes: [NSAttributedString.Key.font: font],
            context: nil
        )
        return ceil(boundingBox.height)
    }

    /// Get estimated width of the text
    ///
    /// - Parameters:
    ///   - height: height of the super view
    ///   - font: font with size to get estimated width
    /// - Returns: Estimated width of the text
    func width(withConstrainedHeight height: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: .greatestFiniteMagnitude, height: height)
        let boundingBox = self.boundingRect(
            with: constraintRect,
            options: .usesLineFragmentOrigin,
            attributes: [NSAttributedString.Key.font: font],
            context: nil
        )
        return ceil(boundingBox.width)
    }
}

 // MARK: Methods
extension String {

    /// Validate Email
    ///
    /// - Parameter testStr: email string
    /// - Returns: true if valid, false otherwise
    static func isValidEmail(emailString: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        return !emailTest.evaluate(with: emailString)
    }

    /// Validate the phone number
    /// - Parameter phoneString: The phone number string
    /// - Returns: true if valid, false otherwise
    static func isValidPhoneNumber(phoneString: String) -> Bool {
        let character  = NSCharacterSet(charactersIn: "+0123456789").inverted
        let inputStringArray = phoneString.components(separatedBy: character)
        let filtered = inputStringArray.joined(separator: "")
        let result = phoneString == filtered
        return !result
    }
}

// MARK: Subscripts
extension String {

    subscript (index: Int) -> Character {
        return self[self.index(startIndex, offsetBy: index)]
    }

    subscript (index: Int) -> String {
        return String(self[index] as Character)
    }

    subscript (range: Range<Int>) -> String {
        let start = index(startIndex, offsetBy: range.lowerBound)
        let end = index(startIndex, offsetBy: range.upperBound - range.lowerBound)
        return String(self[start ..< end])
    }
}

extension String {

    /// Convert from string to `Date` using given format
    /// - Parameter format: The `DateTimeFormat`
    /// - Returns: The `Date` object is the string parsing is successful else nil
    func toDate(format: DateTimeFormat) -> Date? {
        return toDate(format.rawValue)?.date
    }
}

extension String {

    /// Convert to alpha-numeric string
    var alphanumeric: String {
        return self.components(separatedBy: CharacterSet.alphanumerics.inverted).joined().lowercased()
    }
}
