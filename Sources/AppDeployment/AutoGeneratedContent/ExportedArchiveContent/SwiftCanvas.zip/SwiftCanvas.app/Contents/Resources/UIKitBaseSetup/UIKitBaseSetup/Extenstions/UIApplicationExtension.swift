
import UIKit

extension UIApplication {
    
    /// The keyWindow in current `UIScene`
    var keyWindow: UIWindow? {
        if #available(iOS 13, *) {
            return connectedScenes
                .compactMap { $0 as? UIWindowScene }
                .flatMap { $0.windows }
                .first { $0.isKeyWindow }
        } else {
            return windows.first { $0.isKeyWindow }
        }
    }
}
