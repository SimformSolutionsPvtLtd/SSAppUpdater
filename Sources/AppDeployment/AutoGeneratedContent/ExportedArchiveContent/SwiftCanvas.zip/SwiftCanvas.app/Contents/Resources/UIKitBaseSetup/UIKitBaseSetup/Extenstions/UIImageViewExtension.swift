
import UIKit
import Kingfisher

extension UIImageView {
    
    /// Apply drop shadow
    /// - Parameters:
    ///   - shadowColor: Shadow color
    ///   - shadowOffset: Shadow offset
    ///   - cornerRadius: Corner radius of the shadow
    ///   - shadowOpacity: Shadow opacity
    ///   - shadowRadius: Shadow radius
    func applyDropShadow(
        shadowColor: UIColor,
        shadowOffset: CGSize,
        cornerRadius: CGFloat,
        shadowOpacity: Float,
        shadowRadius: CGFloat
    ) {
        self.layer.masksToBounds = false
        self.layer.shadowOpacity = shadowOpacity
        self.layer.shadowOffset = shadowOffset
        self.layer.shadowRadius = shadowRadius
        self.layer.shadowColor = shadowColor.cgColor
    }
    
    /// Load the `UIImageView` using given string URL
    /// - Parameter urlString: The URL in form of a string
    func load(urlString: String) {
        if let url = URL(string: urlString) {
            kf.setImage(with: url)
        }
    }
}
