
import UIKit

extension UIRefreshControl {
    
    /// Begins refreshing the refresh control
    func beginRefreshingManually() {
        if let scrollView = superview as? UIScrollView {
            scrollView.setContentOffset(CGPoint(x: 0,
                                                y: scrollView.contentOffset.y - frame.height),
                                        animated: true)
        }
        beginRefreshing()
    }
}
