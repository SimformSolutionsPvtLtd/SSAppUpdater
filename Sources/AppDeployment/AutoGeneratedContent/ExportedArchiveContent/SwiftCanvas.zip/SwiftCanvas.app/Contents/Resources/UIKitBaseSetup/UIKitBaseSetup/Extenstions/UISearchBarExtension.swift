
import UIKit

/// The name of one of the receiver's properties
private let searchField = "searchField"
private let placeholderLabel = "placeholderLabel"

extension UISearchBar {

    /// Set text color of SearchBar
    /// - Parameter color: The color of the text
    public func setTextColor(color: UIColor) {
        let views = subviews.flatMap { $0.subviews }
        guard let textField = (views.filter { $0 is UITextField }).first as? UITextField else { return }
        textField.textColor = color
        textField.backgroundColor = color
        textField.tintColor = color
        self.setPlaceholderTextColorTo(color: color)
    }

    /// Set placeholder text color
    /// - Parameter color: The color of the placeholder text
    func setPlaceholderTextColorTo(color: UIColor) {
        let textFieldInsideSearchBar = self.value(forKey: searchField) as? UITextField
        textFieldInsideSearchBar?.textColor = color
        let textFieldInsideSearchBarLabel = textFieldInsideSearchBar?.value(forKey: placeholderLabel) as? UILabel
        textFieldInsideSearchBarLabel?.textColor = color
        self.setMagnifyingGlassColorTo(color: color)
    }
    
    /// Set magnifying glass color
    /// - Parameter color: The color of the magnifying glass
    func setMagnifyingGlassColorTo(color: UIColor) {
        let textFieldInsideSearchBar = self.value(forKey: searchField) as? UITextField
        let glassIconView = textFieldInsideSearchBar?.leftView as? UIImageView
        let crossView = textFieldInsideSearchBar?.rightView as? UIImageView
        glassIconView?.image = glassIconView?.image?.withRenderingMode(.alwaysTemplate)
        crossView?.image = crossView?.image?.withRenderingMode(.alwaysTemplate)
        glassIconView?.tintColor = color
        crossView?.tintColor = color
    }
}
