
import UIKit

extension UITableView {

    /// Scroll table to the last row
    func scrollToBottom() {
        DispatchQueue.main.async { [weak self] in
            guard let uSelf = self else { return }
            let indexPath = IndexPath(row: uSelf.numberOfRows(inSection: uSelf.numberOfSections - 1) - 1,
                                      section: uSelf.numberOfSections - 1)
            uSelf.scrollToRow(at: indexPath, at: .bottom, animated: true)
        }
    }

    /// Scroll table to the first row
    func scrollToTop() {
        DispatchQueue.main.async { [weak self] in
            guard let uSelf = self else { return }
            let indexPath = IndexPath(row: 0, section: 0)
            uSelf.scrollToRow(at: indexPath, at: .top, animated: false)
        }
    }
}
