
import UIKit

/// Example of the adapted fonts enum
/// ```swift
/// enum Helvetica {
///
///     static func regular(size: CGFloat) -> UIFont? {
///         UIFont(name: "Helvetica", size: size.adaptedFontSize)
///     }
///
///     static func bold(size: CGFloat) -> UIFont? {
///         UIFont(name: "Helvetica-Bold", size: size.adaptedFontSize)
///     }
/// }
/// ```
