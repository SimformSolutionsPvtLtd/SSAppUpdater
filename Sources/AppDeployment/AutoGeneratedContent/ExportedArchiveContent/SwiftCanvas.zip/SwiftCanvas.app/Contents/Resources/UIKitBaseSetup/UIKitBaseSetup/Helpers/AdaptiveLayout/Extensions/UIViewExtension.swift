
import UIKit

extension UIView {

    func updateAdaptedConstraints() {
        let adaptedConstraints = constraints.compactMap { constraint in
            constraint is AdaptedConstraint ? constraint as? AdaptedConstraint : nil
        }
        for constraint in adaptedConstraints {
            constraint.resetConstant()
            constraint.awakeFromNib()
        }
    }
}
