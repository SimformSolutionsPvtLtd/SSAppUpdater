
import Foundation
import UIKitBaseSetupSecrets
import UIKitBaseSetupSecretsInterfaces

/// A namespace for the app secret variables
public struct AppSecrets {

    private static var environment: SecretsEnvironmentProtocol {
        #if Development
        return Secrets.Development()
        #elseif Production
        return Secrets.Production()
        #elseif Staging
        return Secrets.Staging()
        #elseif UAT
        return Secrets.UAT()
        #else
        fatalError("Build environment not found!!")
        #endif
    }

    static let sentryKey = environment.sentryDNSKey
    static let globalKey = Secrets.Global().globalKey
}
