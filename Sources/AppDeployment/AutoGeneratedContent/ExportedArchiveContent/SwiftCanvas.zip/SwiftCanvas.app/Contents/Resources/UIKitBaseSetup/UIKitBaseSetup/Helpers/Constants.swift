
import Foundation

/// Constants of the project
/// All the hardcoded literals should be places here with proper naming and proper namespace
struct Constants {

    // MARK: Static constants
    static let three = 3
    static let four = 4
    static let five = 5
    static let six = 6
    static let seven = 7
    static let eight = 8
    static let nine = 9
    static let ten = 10
    
    struct URL {
        #if Development
        static let baseURL = "https://randomuser.me/api/"
        #elseif Production
        static let baseURL = "https://www.simform.com/Production"
        #elseif Staging
        static let baseURL = "https://www.simform.com/Staging"
        #elseif UAT
        static let baseURL = "https://www.simform.com/UAT"
        #else
        #endif
        
        #if Development
        static let awsURL = "https://appname.amazonaws.com/Development"
        #elseif Production
        static let awsURL = "https://appname.amazonaws.com/Production"
        #elseif Staging
        static let awsURL = "https://appname.amazonaws.com/Staging"
        #elseif UAT
        static let awsURL = "https://appname.amazonaws.com/UAT"
        #else
        #endif
    }
}
