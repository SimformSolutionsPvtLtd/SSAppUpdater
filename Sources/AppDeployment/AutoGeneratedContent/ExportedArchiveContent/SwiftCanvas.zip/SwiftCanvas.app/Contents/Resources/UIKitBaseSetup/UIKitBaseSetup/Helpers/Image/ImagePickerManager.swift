
import UIKit
import AVKit
import Photos

/// Image picker manager with helper methods
/// - Image picker methods
/// - Check camera permission
/// - Check gallery permission
/// - Open camera
/// - Open Gallery
class ImagePickerManager: NSObject, UINavigationControllerDelegate {

    private var picker = UIImagePickerController()
    private var alert: UIAlertController?
    private weak var viewController: UIViewController?
    private var pickImageCallback: ((UIImage?) -> Void)?

    /// Pick image
    /// - Parameters:
    ///   - viewController: The view controller on which the picker view controller needs to be presented
    ///   - sourceView: The source view for the popover view controller
    ///   - showRemovePhoto: true if picker image needs te presented, false otherwise
    ///   - callback: The callback closure
    ///   - showImage: The closure to show the picked image
    func pickImage(
        _ viewController: UIViewController,
        sourceView: UIView,
        showRemovePhoto: Bool,
        _ callback: @escaping ((UIImage?) -> Void),
        _ showImage: @escaping ((Bool) -> Void)
    ) {
        pickImageCallback = callback
        self.viewController = viewController

        let showImageAction = createShowImageAction(showRemovePhoto, showImage)
        let removeImageAction = createRemoveImageAction()
        let cameraAction = createCameraAction()
        let galleryAction = createGalleryAction()
        let cancelAction = createCancelAction(showImage)

        // Add the actions
        picker.delegate = self
        var actionArray  = [cameraAction, galleryAction, cancelAction]
        if showRemovePhoto {
            actionArray.insert(removeImageAction, at: 0)
            actionArray.insert(showImageAction, at: 0)
        }
        alert = UIAlertController.createAlert(
            title: AppStrings.chooseImage(),
            message: nil,
            actions: actionArray,
            preferredStyle: .actionSheet
        )
        if let alert = alert {
            alert.popoverPresentationController?.sourceView = sourceView
            alert.popoverPresentationController?.sourceRect = CGRect(
                x: sourceView.bounds.origin.x,
                y: sourceView.bounds.origin.y,
                width: sourceView.bounds.width,
                height: sourceView.bounds.height
            )
            viewController.present(alert, animated: true, completion: nil)
        }
    }

    /// Create open gallery action
    /// - Returns: The `UIAlertAction`
    private func createGalleryAction() -> UIAlertAction {
        UIAlertAction(title: AppStrings.photos(), style: .default) { [weak self] _ in
            self?.checkForGalleryPermission(completion: { (success) in
                if success {
                    self?.openGallery()
                } else {
                    self?.showAlert(
                        title: AppStrings.unableToAccessThe() + AppStrings.photos(),
                        message: AppStrings.toEnableAccessThePhotos()
                    )
                }
            })
        }
    }

    /// Check for camera permission
    /// - Parameter completion: The callback with `Bool` value indicating camera permission is granted or not
    func checkForCameraPermission(completion: @escaping (Bool) -> Void) {
        // Camera
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .notDetermined:
            // ask for permissions
            AVCaptureDevice.requestAccess(for: .video, completionHandler: { (granted: Bool) in
                if granted {
                    completion(true)
                } else {
                    completion(false)
                }
            })
        case .restricted, .denied:
            completion(false)
        case .authorized:
            completion(true)
            // Default case added by swift 5 this will never execute
        @unknown default:
            fatalError("checkForCameraPermission")
        }
    }

    /// Check for gallery permission
    /// - Parameter completion: The callback with `Bool` value indicating gallray permission is granted or not
    func checkForGalleryPermission(completion: @escaping (Bool) -> Void) {
        let status = PHPhotoLibrary.authorizationStatus()
        switch status {
        case .authorized:
            completion(true)
        case .denied, .restricted:
            completion(false)
        case .notDetermined:
            // ask for permissions
            PHPhotoLibrary.requestAuthorization { newStatus in
                switch newStatus {
                case .authorized:
                    completion(true)
                case .denied, .restricted:
                    completion(false)
                case .notDetermined:
                    completion(false)
                case .limited:
                    completion(false)
                @unknown default:
                    completion(false)
                }
            }
        case .limited:
            completion(false)
        @unknown default:
            completion(false)
        }
    }

    /// Show Alert
    /// - Parameters:
    ///   - title: The title of the alert
    ///   - message: The message of the alert
    func showAlert(title: String, message: String) {
        self.alert?.dismiss(animated: true, completion: nil)
        let okAction = UIAlertAction(title: AppStrings.ok(), style: .cancel, handler: nil)
        let settingsAction = UIAlertAction(title: AppStrings.settings(), style: .default, handler: { _ in
            // Take the user to Settings app to possibly change permission.
            guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else { return }
            if UIApplication.shared.canOpenURL(settingsUrl) {
                UIApplication.shared.open(settingsUrl) { _ in
                    // Finished opening URL
                }
            }
        })

        let settingsAlert = UIAlertController.createAlert(
            title: title,
            message: message,
            actions: [okAction, settingsAction],
            preferredStyle: .alert
        )
        self.viewController?.present(settingsAlert, animated: true, completion: nil)
    }

    /// Open camera
    func openCamera() {
        alert?.dismiss(animated: true, completion: nil)
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            picker.sourceType = .camera
            self.viewController?.present(picker, animated: true, completion: nil)
        } else {
            let cancelAction = UIAlertAction(title: AppStrings.cancel(), style: .cancel) { _ in
            }
            let alertWarning = UIAlertController.createAlert(
                title: AppStrings.warning(),
                message: AppStrings.youDoNotHaveCamera(),
                actions: [cancelAction],
                preferredStyle: .alert
            )
            if let view = self.viewController?.view {
                alertWarning.popoverPresentationController?.sourceView = view
                viewController?.present(alertWarning, animated: true, completion: nil)
            }
        }
    }

    /// Open gallery
    func openGallery() {
        alert?.dismiss(animated: true, completion: nil)
        picker.sourceType = .photoLibrary
        self.viewController?.present(picker, animated: true, completion: nil)
    }

    /// Remove picked image
    func removeImage() {
        pickImageCallback?(nil)
    }
}

// MARK: UIImagePickerControllerDelegate
extension ImagePickerManager: UIImagePickerControllerDelegate {

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }

    func imagePickerController(
        _ picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]
    ) {
        picker.dismiss(animated: true, completion: nil)
        guard let image = info[.originalImage] as? UIImage else {
            print("Not getting image")
            return
        }
        pickImageCallback?(image)
    }

    @objc func imagePickerController(_ picker: UIImagePickerController, pickedImage: UIImage?) {
        print("@objc func imagePickerController called")
    }
}

// MARK: Private methods
extension ImagePickerManager {

    /// Create cancel action
    /// - Parameter showImage: The show image callback, fired with false
    /// - Returns: The `UIAlertAction`
    private func createCancelAction(_ showImage: @escaping ((Bool) -> Void)) -> UIAlertAction {
        UIAlertAction(title: AppStrings.cancel(), style: .cancel) { _ in
            showImage(false)
        }
    }

    /// Create camera action
    /// - Returns: The `UIAlertAction`
    private func createCameraAction() -> UIAlertAction {
        UIAlertAction(title: AppStrings.camera(), style: .default) { _ in
            self.checkForCameraPermission(completion: { (success) in
                if success {
                    self.openCamera()
                } else {
                    DispatchQueue.main.async { [weak self] in
                        guard let uSelf = self else {
                            return
                        }
                        uSelf.showAlert(
                            title: AppStrings.unableToAccessThe() + AppStrings.camera(),
                            message: AppStrings.toEnableAccessTheCamera()
                        )
                    }
                }
            })
        }
    }

    /// Create show image action
    /// - Parameters:
    ///   - showRemovePhoto: whether removed photo needs to be shown or not
    ///   - showImage: The show image closure to show the image
    /// - Returns: The `UIAlertAction`
    private func createShowImageAction(_ showRemovePhoto: Bool,
                                       _ showImage: @escaping ((Bool) -> Void)) -> UIAlertAction {
        UIAlertAction(title: AppStrings.showPhoto(), style: .default) { _ in
            showImage(showRemovePhoto)
        }
    }

    /// Create remove image action
    /// - Returns: The `UIAlertAction`
    private func createRemoveImageAction() -> UIAlertAction {
        UIAlertAction(title: AppStrings.removePhoto(), style: .default) { [weak self] _ in
            self?.removeImage()
        }
    }
}
