
import UIKit

/// For the use case of #function refer below link
/// https://reintech.io/term/understanding-function-in-swift-programming
class UserManager {

    static let shared = UserManager()

    private init() { }

    private let userDefaults = UserDefaults.standard

    var isUserLogin: Bool {
        get {
            return getBool(#function)
        }

        set (newValue) {
            userDefaults.set(newValue, forKey: #function)
        }
    }

    // user token data
    var accessToken: String? {
        get {
            KeychainManager.shared[#function]
        }

        set (newValue) {
            KeychainManager.shared[#function] = newValue
        }
    }

    // user refresh token data
    var refreshToken: String? {
        get {
            KeychainManager.shared[#function]
        }

        set (newValue) {
            KeychainManager.shared[#function] = newValue
        }
    }

    private func getBool(_ key: String) -> Bool {
        return userDefaults.object(forKey: key) as? Bool ?? false
    }
}

extension UserManager {

    // Clear all user defaults
    func clearAllData() {
        guard let domain = Bundle.main.bundleIdentifier else { return }
        userDefaults.removePersistentDomain(forName: domain)
        accessToken = nil
        refreshToken = nil
    }
}

extension UserDefaults {

    static func exists(key: String) -> Bool {
        return UserDefaults.standard.object(forKey: key) != nil
    }
}
