
import Foundation
import NetworkEngine

/// Defines the APIs available
public enum APITarget: NetworkRepo {
    case refreshToken
    case login(email: String, password: String)
    case demo(demoData: DemoRequestModel)
    case fetchUsers(userListRequest: UserListRequest)
    case uploadFile(file: URL)
    case downloadFile(file: URL, destination: DestinationWrapper)
}

extension APITarget {

    public var timeoutInterval: TimeInterval {
        60.0 // Seconds
    }

    public var baseURL: URL {
        guard let baseURL = URL(string: Constants.URL.baseURL) else {
            fatalError("Invalid base URL: \(Constants.URL.baseURL)")
        }
        switch self {
        case .downloadFile(let file, _):
            return file
        default:
            return baseURL
        }
    }

    public var path: String {
        switch self {
        case .login:
            return "login"
        case .refreshToken:
            return "refreshToken"
        case .demo:
            return "demo"
        case .fetchUsers, .uploadFile, .downloadFile:
            return ""
        }
    }

    public var method: NetworkEngine.Method {
        switch self {
        case .login, .refreshToken, .demo, .uploadFile:
            return .post
        case .fetchUsers, .downloadFile:
            return .get
        }
    }

    public var task: NetworkTask {
        switch self {
        case .demo(let demoData):
            let jsonEncoder = JSONEncoder()
            jsonEncoder.keyEncodingStrategy = .convertToSnakeCase
            return .requestCustomJSONEncodable(
                demoData,
                encoder: jsonEncoder
            )
        case .login(let name, let password):
            let parameters = ["email": name, "password": password]
            return .requestParameters(
                parameters: parameters,
                encoding: URLEncoding.default
            )
        case .fetchUsers(let userListRequest):
            return .requestParameterEncodable(userListRequest)
        case .refreshToken:
            return .requestPlain
        case .uploadFile(file: let file):
            return .uploadFile(file)
        case .downloadFile(_, let destination):
            return .downloadDestination(destination.destination, nil)
        }
    }

    public var keyDecodingStrategy: KeyDecodingStrategy {
        switch self {
        case .login, .refreshToken, .demo, .fetchUsers, .uploadFile, .downloadFile:
            return .convertFromSnakeCase
        }
    }

    public var headers: [String: String]? {
        return [
            "Accept-Version": "v1"
        ]
    }
}

// MARK: Static objects for network calls
extension APITarget {

    static let interceptor = DefaultInterceptor(refreshTokenCall)
    static let provider = NetworkProvider<APITarget>(interceptor: interceptor)

    static func refreshTokenCall(_ completion: @escaping (Bool) -> Void) {
        refreshToken.request(type: SessionModel.self) { response in
            switch response {
            case .success(let data):
                UserManager.shared.accessToken = data.accessToken ?? ""
                UserManager.shared.refreshToken = data.refreshToken ?? ""
                completion(true)
            case .failure:
                completion(false)
            }
        }
    }
}

// MARK: NetworkRequestable conformance
extension APITarget {

    func request<T>(type: T.Type,
                    callback: @escaping (Result<T, NetworkEngine.NetworkError>) -> Void) where T: Decodable {
        APITarget.provider.request(self, type: type, completion: callback)
    }

    func downloadTask(progressHandler: ProgressHandler?) -> DownloadTask {
        return APITarget.provider.download(self,
                                           progressHandler: progressHandler)
    }
}
