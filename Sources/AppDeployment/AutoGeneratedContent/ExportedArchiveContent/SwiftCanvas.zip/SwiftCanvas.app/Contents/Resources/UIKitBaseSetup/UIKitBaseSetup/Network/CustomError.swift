
import Foundation

/// Custom error to throw with
///  - title: String
///  - body: String
struct CustomError: Error, Equatable {
    let title: String
    let body: String

    /// No internet error object
    static let noInternetError = CustomError(title: AppStrings.noInternetConnection(),
                                             body: AppStrings.pleaseConnectToInternet())

    /// Generic error object
    static let genericError = CustomError(title: AppStrings.genericError(),
                                          body: AppStrings.somethingWentWrong())
}
