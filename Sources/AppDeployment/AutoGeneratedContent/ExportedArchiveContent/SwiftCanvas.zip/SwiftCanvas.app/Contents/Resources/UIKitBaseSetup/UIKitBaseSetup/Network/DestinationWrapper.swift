
import Foundation
import NetworkEngine

/// A wrapper on `DownloadDestination`
public class DestinationWrapper {

    let destination: DownloadDestination

    // MARK: Initialization
    init(destination: @escaping DownloadDestination) {
        self.destination = destination
    }
}