
import Foundation
import NetworkEngine

/// Defines the available network calls with their input types
protocol NetworkRepo: TargetType & NetworkRequestable {
    static var refreshToken: Self { get }
    static func login(email: String, password: String) -> Self
    static func demo(demoData: DemoRequestModel) -> Self
    static func fetchUsers(userListRequest: UserListRequest) -> Self
    static func uploadFile(file: URL) -> Self
    static func downloadFile(file: URL, destination: DestinationWrapper) -> Self
}
