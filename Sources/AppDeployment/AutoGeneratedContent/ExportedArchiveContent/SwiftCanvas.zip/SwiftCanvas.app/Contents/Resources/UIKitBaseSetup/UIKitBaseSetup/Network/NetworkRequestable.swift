
import Foundation
import NetworkEngine

/// Defines the network call methods
protocol NetworkRequestable {

    /// Request the data in form of `T`
    /// - Parameters:
    ///   - type: The type of `T`
    ///   - callback: The callback handler
    func request<T: Decodable>(type: T.Type,
                               callback: @escaping (Result<T, NetworkError>) -> Void)

    /// Download the the data and get the `Data` of the download
    /// - Parameters:
    ///   - progressHandler: The `ProgressHandler`
    /// - Returns: The `DownloadTask`
    func downloadTask(progressHandler: ProgressHandler?) -> DownloadTask
}
