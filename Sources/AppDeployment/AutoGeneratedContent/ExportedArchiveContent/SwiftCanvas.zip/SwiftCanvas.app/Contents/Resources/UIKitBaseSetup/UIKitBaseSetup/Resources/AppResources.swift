
import Foundation

let AppStrings = R.string.localizable
let AppStoryboards = R.storyboard
let AppColors = R.color
let AppNibs = R.nib
