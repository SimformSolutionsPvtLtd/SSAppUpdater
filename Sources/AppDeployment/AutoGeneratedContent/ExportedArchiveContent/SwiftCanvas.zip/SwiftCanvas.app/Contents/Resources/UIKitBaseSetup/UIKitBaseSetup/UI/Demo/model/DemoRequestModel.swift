
import Foundation

/// Demo request model
public struct DemoRequestModel: Encodable {
    let firstParam: String
    let secondParam: String
}
