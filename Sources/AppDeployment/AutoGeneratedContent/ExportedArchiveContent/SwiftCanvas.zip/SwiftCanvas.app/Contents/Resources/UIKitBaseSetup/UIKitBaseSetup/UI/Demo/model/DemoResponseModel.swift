
import Foundation

/// Demo response model
struct DemoResponseModel: Encodable {
    let title: String
    let data: [String]
}
