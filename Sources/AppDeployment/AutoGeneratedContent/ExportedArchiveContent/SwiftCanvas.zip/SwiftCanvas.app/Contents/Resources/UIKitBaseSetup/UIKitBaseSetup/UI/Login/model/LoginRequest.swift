
import Foundation

/// Login request model
struct LoginRequest: Codable {
    let email: String
    let password: String
}
