
import Foundation

/// Login response model
struct LoginResponse: Codable {
    let token: String
}
