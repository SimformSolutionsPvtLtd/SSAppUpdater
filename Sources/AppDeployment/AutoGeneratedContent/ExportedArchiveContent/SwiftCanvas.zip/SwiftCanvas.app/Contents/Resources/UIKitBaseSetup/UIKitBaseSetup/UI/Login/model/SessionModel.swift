
import Foundation

/// The session model with access token, refresh token, token type, access token expiry
struct SessionModel: Codable {
    let accessToken: String?
    let tokenType: String?
    let refreshToken: String?
    let expiresIn: String?
}
