
import UIKit

/// MainViewController, the home screen of the project
class MainViewController: BaseViewController {

    // MARK: Outlets
    @IBOutlet weak var userTable: UITableView!

    // MARK: Private variables
    private let activityIndicator = UIActivityIndicatorView(style: .medium)
    private let mainViewModel: MainViewModel = MainViewModel(networkRepo: APITarget.self)
    private var users = [UserData]()

    // MARK: Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        bindViewModel()
        mainViewModel.getNewPage()
    }
}

// MARK: Private methods
extension MainViewController {

    /// Setup the UI components
    private func setup() {
        activityIndicator.frame = CGRect(x: CGFloat(0),
                                         y: CGFloat(0),
                                         width: userTable.bounds.width,
                                         height: CGFloat(44))
        self.userTable.tableFooterView = activityIndicator
        userTable.estimatedRowHeight = 104
        let nib = UINib(nibName: AppNibs.userCell.name, bundle: Bundle.main)
        userTable.register(nib, forCellReuseIdentifier: R.reuseIdentifier.userCell.identifier)
    }

    /// Bind the ViewModel dynamic variables with actions
    private func bindViewModel() {
        mainViewModel.showLoading.bind { [weak self] showLoading in
            self?.showLoadingIndicator(show: showLoading)
        }
        mainViewModel.error.bind { [weak self] error in
            guard let error = error else { return }
            log.error(error.localizedDescription.log)
            self?.showDialogue(title: error.title, message: error.body)
        }
        mainViewModel.userLists.bind { [weak self] users in
            self?.users.append(contentsOf: users)
            DispatchQueue.main.async { [weak self] in
                self?.userTable.reloadData()
            }
        }
    }

    /// Show/Hide loading indicator
    /// - Parameter show: true if loading needs to be shown, false otherwise
    private func showLoadingIndicator(show: Bool) {
        userTable.tableFooterView?.isHidden = !show
        if show {
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
        }
    }
}

// MARK: UITableViewDataSource
extension MainViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.userCell.identifier,
                                                       for: indexPath) as? UserCell else {
            return UITableViewCell()
        }
        cell.configure(user: users[indexPath.row])
        return cell
    }
}

// MARK: UITableViewDelegate
extension MainViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let detailsViewController = AppStoryboards.main.userDetailsViewController() else {
            return
        }
        detailsViewController.userData = users[indexPath.row]
        self.navigationController?.pushViewController(detailsViewController, animated: true)
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row > users.count - 2 {
            mainViewModel.getNewPage()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
