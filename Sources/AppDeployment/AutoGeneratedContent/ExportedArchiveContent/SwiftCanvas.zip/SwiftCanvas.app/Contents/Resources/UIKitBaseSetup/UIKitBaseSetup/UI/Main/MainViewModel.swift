
import Foundation
import NetworkEngine

/// MainViewModel for `MainViewController`
class MainViewModel: BaseViewModel {

    // MARK: Private variables
    private let networkRepo: NetworkRepo.Type
    private var pageNumber = 0

    // MARK: Dynamic vars
    let userLists: Dynamic<[UserData]> = Dynamic([])

    // MARK: Initialization
    init(networkRepo: NetworkRepo.Type) {
        self.networkRepo = networkRepo
    }

    /// Get new page
    func getNewPage() {
        pageNumber += 1
        let requestURLParameters = UserListRequest(results: 10, page: pageNumber)
        let usersListCall = networkRepo.fetchUsers(userListRequest: requestURLParameters)
        showLoading.value = true
        usersListCall.request(type: UserListResponse.self) { [weak self] result in
            self?.showLoading.value = false
            switch result {
            case .success(let userResponse):
                self?.userLists.value = userResponse.results
            case .failure(let error):
                self?.error.value = ErrorConverter.convert(error)
            }
        }
    }
}
