
import UIKit

/// Table view cell to list the user info
class UserCell: UITableViewCell {
    
    // MARK: Outlets
    @IBOutlet weak var imgUserProfile: UIImageView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblUserinfo: UILabel!

    /// Configure this cell
    /// - Parameter user: The `UserData`
    func configure(user: UserData) {
        lblUserName.text = user.name.first + user.name.last
        lblUserinfo.text = user.email
        imgUserProfile.load(urlString: user.picture.thumbnail)
    }
}
