
import Foundation

/// The user list request model
public struct UserListRequest: Codable {
    let results: Int
    let page: Int
}
