
import Foundation

/// UserListResponse
struct UserListResponse: Codable {
    let results: [UserData]
    let info: Info
}

/// Info
struct Info: Codable {
    let seed: String
    let results, page: Int
    let version: String
}

/// UserData
struct UserData: Codable {
    let gender: Gender
    let name: Name
    let location: UserAddress
    let email: String
    let login: LoginInfo
    let dob, registered: Dob
    let phone, cell: String
    let userId: UserId
    let picture: Picture
    let nat: String

    enum CodingKeys: String, CodingKey {
        case gender
        case name
        case location
        case email
        case login
        case dob
        case registered
        case phone
        case cell
        case userId = "id"
        case picture
        case nat
    }
}

/// Date of birth
struct Dob: Codable {
    let date: String
    let age: Int
}

/// Gender
enum Gender: String, Codable {
    case female
    case male
}

/// User ID
struct UserId: Codable {
    let name: String
    let value: String?
}

/// User address
struct UserAddress: Codable {
    let street: Street
    let city, state, country: String
    let postcode: Postcode
    let coordinates: Coordinates
    let timezone: Timezone
}

/// Coordinates
struct Coordinates: Codable {
    let latitude, longitude: String
}

/// Postal code
enum Postcode: Codable {
    case integer(Int)
    case string(String)

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let value = try? container.decode(Int.self) {
            self = .integer(value)
            return
        }
        if let value = try? container.decode(String.self) {
            self = .string(value)
            return
        }
        throw DecodingError.typeMismatch(Postcode.self,
                                         DecodingError.Context(codingPath: decoder.codingPath,
                                                               debugDescription: "Wrong type for Postcode"))
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .integer(let value):
            try container.encode(value)
        case .string(let value):
            try container.encode(value)
        }
    }
}

/// Street address
struct Street: Codable {
    let number: Int
    let name: String
}

/// Timezone
struct Timezone: Codable {
    let offset, description: String
}

/// Login info
struct LoginInfo: Codable {
    let uuid, username, password, salt: String
    let md5, sha1, sha256: String
}

/// Name
struct Name: Codable {
    let title: String
    let first, last: String
}

/// User picture
struct Picture: Codable {
    let large, medium, thumbnail: String
}
