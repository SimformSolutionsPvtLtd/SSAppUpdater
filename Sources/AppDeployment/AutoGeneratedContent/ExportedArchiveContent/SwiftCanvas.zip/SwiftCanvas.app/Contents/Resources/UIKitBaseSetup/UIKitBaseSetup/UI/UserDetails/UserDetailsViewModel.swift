
import Foundation
import NetworkEngine

/// User details view model for `UserDetailsViewController`
class UserDetailsViewModel: BaseViewModel {

    // MARK: Private vars
    private let networkRepo: NetworkRepo.Type

    // MARK: Public vars
    let downloadSuccess: Dynamic<URL?> = Dynamic(nil)

    // MARK: Initialization
    init(networkRepo: NetworkRepo.Type) {
        self.networkRepo = networkRepo
    }

    /// Download the profile images of the given `user`
    /// - Parameter userData: The `UserData`
    func downloadProfileImage(userData: UserData) {
        guard let url = URL(string: userData.picture.large),
              let folder = try? FileManager.default.url(for: .documentDirectory,
                                                        in: .userDomainMask,
                                                        appropriateFor: nil,
                                                        create: true).appendingPathComponent("ProfileImages") else { return }
        let downloadDestination: DownloadDestination = { _, _ in
            let fileURL = folder.appendingPathComponent(userData.email + ".png")
            return (fileURL, [.removePreviousFile, .createIntermediateDirectories])
        }

        let destination = DestinationWrapper(destination: downloadDestination)

        showLoading.value = true
        let completion = { [weak self] (result: Result<URL?, NetworkError>) in
            self?.showLoading.value = false
            switch result {
            case .success(let url):
                self?.downloadSuccess.value = url
            case .failure(let error):
                self?.error.value = ErrorConverter.convert(error)
            }
        }
        let progressHandler: ProgressHandler = { progress in
            print(progress)
        }
        let task = networkRepo.downloadFile(file: url,
                                            destination: destination).downloadTask(progressHandler: progressHandler)
        task.download(completion: completion)
    }
}
