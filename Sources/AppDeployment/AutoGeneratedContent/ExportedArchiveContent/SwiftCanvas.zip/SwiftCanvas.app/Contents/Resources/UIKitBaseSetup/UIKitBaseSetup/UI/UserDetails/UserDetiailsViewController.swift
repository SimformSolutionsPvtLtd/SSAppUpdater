
import UIKit

/// User details view controller for displaying user details
class UserDetailsViewController: BaseViewController {
    
    // MARK: IBOutlets
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var imgUserProfile: UIImageView!
    @IBOutlet weak var btnDownload: UIButton!

    // MARK: Public variables
    var userData: UserData! = nil

    // MARK: Private variables
    private let userDetailsViewModel = UserDetailsViewModel(networkRepo: APITarget.self)

    // MARK: Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        bindViewModel()
    }

    // MARK: IBActions
    @IBAction func downloadButtonAction(_ sender: UIButton) {
        userDetailsViewModel.downloadProfileImage(userData: userData)
    }

    override func viewDidLayoutSubviews() {
        imgUserProfile.layer.cornerRadius = imgUserProfile.bounds.height / 2
    }
}

// MARK: Private methods
extension UserDetailsViewController {

    /// Setup UI components
    private func setup() {
        imgUserProfile.load(urlString: userData.picture.large)
        activityIndicator.isHidden = true
    }

    /// Bind the ViewModel dynamic variables with actions
    private func bindViewModel() {
        userDetailsViewModel.showLoading.bind { [weak self] showLoading in
            self?.showLoadingIndicator(show: showLoading)
        }
        userDetailsViewModel.error.bind { [weak self] error in
            guard let error = error else { return }
            log.error(error.localizedDescription.log)
            self?.showDialogue(title: error.title, message: error.body)
        }
        userDetailsViewModel.downloadSuccess.bind { [weak self] url in
            guard let url = url else { return }
            self?.showDialogue(title: AppStrings.downloaded(), message: url.lastPathComponent)
        }
    }

    /// Show/Hide loading indicator
    /// - Parameter show: true if loading needs to be shown, false otherwise
    private func showLoadingIndicator(show: Bool) {
        activityIndicator.isHidden = !show
        btnDownload.isHidden = show
        if show {
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
        }
    }
}
