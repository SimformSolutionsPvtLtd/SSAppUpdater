
import Foundation
import NetworkEngine
@testable import UIKitBaseSetup

public enum MockAPITarget: NetworkRepo {
    case refreshToken
    case login(email: String, password: String)
    case demo(demoData: DemoRequestModel)
    case fetchUsers(userListRequest: UserListRequest)
    case uploadFile(file: URL)
    case downloadFile(file: URL, destination: DestinationWrapper)
}

extension MockAPITarget {

    public var timeoutInterval: TimeInterval {
        60.0 // Seconds
    }

    public var baseURL: URL {
        guard let baseURL = URL(string: Constants.URL.baseURL) else {
            fatalError("Invalid base URL: \(Constants.URL.baseURL)")
        }
        switch self {
        case .downloadFile(let file, _):
            return file
        default:
            return baseURL
        }
    }

    public var path: String {
        switch self {
        case .login:
            return "login"
        case .refreshToken:
            return "refreshToken"
        case .demo:
            return "demo"
        case .fetchUsers, .uploadFile, .downloadFile:
            return ""
        }
    }

    public var method: NetworkEngine.Method {
        switch self {
        case .login, .refreshToken, .demo, .uploadFile:
            return .post
        case .fetchUsers, .downloadFile:
            return .get
        }
    }

    public var task: NetworkTask {
        switch self {
        case .demo(let demoData):
            let jsonEncoder = JSONEncoder()
            jsonEncoder.keyEncodingStrategy = .convertToSnakeCase
            return .requestCustomJSONEncodable(
                demoData,
                encoder: jsonEncoder
            )
        case .login(let name, let password):
            let parameters = ["email": name, "password": password]
            return .requestParameters(
                parameters: parameters,
                encoding: URLEncoding.default
            )
        case .fetchUsers(let userListRequest):
            return .requestParameterEncodable(userListRequest)
        case .refreshToken:
            return .requestPlain
        case .uploadFile(file: let file):
            return .uploadFile(file)
        case .downloadFile(_, let destination):
            return .downloadDestination(destination.destination, nil)
        }
    }

    public var keyDecodingStrategy: KeyDecodingStrategy {
        switch self {
        case .login, .refreshToken, .demo, .fetchUsers, .uploadFile, .downloadFile:
            return .convertFromSnakeCase
        }
    }

    public var headers: [String: String]? {
        return [
            "Accept-Version": "v1"
        ]
    }
}

extension MockAPITarget {

    static var apiCallDelay = 4 // milliseconds
    static var errorToThrow: NetworkError?

    public func request<T: Decodable>(type: T.Type,
                                      callback: @escaping (Result<T, NetworkError>) -> Void) {
        self.sendMockResponse(callback)
    }
    
    public func downloadTask(progressHandler: NetworkEngine.ProgressHandler?) -> NetworkEngine.DownloadTask {
        return MockDownloadTask()
    }

    // swift_lint: cyclomatic_complexity
    private func sendMockResponse<T: Decodable>(_ callback: @escaping (Result<T, NetworkError>) -> Void) {
        let asyncAfter: DispatchTime = .now() + DispatchTimeInterval.milliseconds(MockAPITarget.apiCallDelay)
        DispatchQueue.global().asyncAfter(deadline: asyncAfter) {
            if let errorToThrow = MockAPITarget.errorToThrow {
                callback(.failure(errorToThrow))
                return
            }
            switch self {
            case .refreshToken:
                if let response = T.parse(jsonFile: "") {
                    callback(.success(response))
                    return
                }
            case .login:
                if let response = T.parse(jsonFile: "") {
                    callback(.success(response))
                    return
                }
            case .demo:
                if let response = T.parse(jsonFile: "") {
                    callback(.success(response))
                    return
                }
            case .fetchUsers:
                if let response = T.parse(jsonFile: "UserListResponse") {
                    callback(.success(response))
                    return
                }
            case .uploadFile, .downloadFile:
                break
            }
            callback(.failure(TestErrors.explicitlyCancelled))
        }
    }
}
