
import Combine
import NetworkEngine

class MockDownloadTask: DownloadTask {
    
    func cancel(_ callback: @escaping (Data?) -> Void) {
        fatalError("Not implemented")
    }
    
    func cancelProducingData() async -> Data? {
        fatalError("Not implemented")
    }
    
    func download(completion: @escaping (Result<URL?, NetworkEngine.NetworkError>) -> Void) {
        fatalError("Not implemented")
    }
    
    func download(completion: @escaping (Result<Data, NetworkEngine.NetworkError>) -> Void) {
        fatalError("Not implemented")
    }
    
    func download() -> AnyPublisher<Result<URL, NetworkEngine.NetworkError>, Never> {
        fatalError("Not implemented")
    }
    
    func download() -> AnyPublisher<Result<Data, NetworkEngine.NetworkError>, Never> {
        fatalError("Not implemented")
    }
    
    func download() async -> Result<URL, NetworkEngine.NetworkError> {
        fatalError("Not implemented")
    }
    
    func download() async -> Result<Data, NetworkEngine.NetworkError> {
        fatalError("Not implemented")
    }
}
