
import Alamofire
import NetworkEngine

enum TestErrors {
    
    static let explicitlyCancelled = NetworkError.networkError(AFError.explicitlyCancelled, nil, nil)
}
