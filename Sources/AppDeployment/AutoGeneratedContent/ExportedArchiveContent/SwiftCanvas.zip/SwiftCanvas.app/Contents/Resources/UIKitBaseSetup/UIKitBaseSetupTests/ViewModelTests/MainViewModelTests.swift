
import XCTest
import NetworkEngine
import Alamofire
@testable import UIKitBaseSetup

final class MainViewModelTests: XCTestCase {
    
    var sut: MainViewModel!
    
    override func setUpWithError() throws {
        sut = MainViewModel(networkRepo: MockAPITarget.self)
    }

    override func tearDownWithError() throws {
        sut = nil
        MockAPITarget.errorToThrow = nil
    }

    func testUserListAPISuccess() {
        // Given
        MockAPITarget.errorToThrow = nil

        sut.userLists.bind { users in
            // Then
            XCTAssert(!users.isEmpty)
            XCTAssert(users.count == 10)
        }
        sut.error.bind { error in
            // Then
            XCTAssertNil(error)
        }

        // When
        sut.getNewPage()
    }

    func testUserListAPIFailure() {
        // Given
        let errorToThrow = TestErrors.explicitlyCancelled
        MockAPITarget.errorToThrow = errorToThrow

        sut.userLists.bind { users in
            // Then
            XCTAssert(false)
        }
        sut.error.bind { error in
            // Then
            XCTAssertNotNil(error)
            XCTAssert(error == ErrorConverter.convert(errorToThrow))
        }

        // When
        sut.getNewPage()
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
}
