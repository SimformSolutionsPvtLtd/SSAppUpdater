require 'xcodeproj'

def update_bundle_identifier(project_path, new_bundle_identifier)
  project = Xcodeproj::Project.open(project_path)
  updated = false

  project.targets.each do |target|
    target.build_configurations.each do |config|
      if config.build_settings['PRODUCT_BUNDLE_IDENTIFIER']
        puts "Updating target '#{target.name}' configuration '#{config.name}' from '#{config.build_settings['PRODUCT_BUNDLE_IDENTIFIER']}' to '#{new_bundle_identifier}'"
        config.build_settings['PRODUCT_BUNDLE_IDENTIFIER'] = new_bundle_identifier
        updated = true
      else
        puts "No bundle identifier found for target '#{target.name}' configuration '#{config.name}'"
      end
    end
  end

  if updated
    project.save
    puts "Bundle identifier updated successfully to #{new_bundle_identifier} for all targets"
  else
    puts "No bundle identifiers were updated. Ensure that your project has targets with 'PRODUCT_BUNDLE_IDENTIFIER' set."
  end
end

# Check if the correct number of arguments are provided
if ARGV.length != 2
  puts "Usage: ruby update_bundle_identifier.rb <project_path> <new_bundle_identifier>"
  exit
end

# Get the arguments
project_path = ARGV[0]
new_bundle_identifier = ARGV[1]

# Update the bundle identifier
update_bundle_identifier(project_path, new_bundle_identifier)
