
require 'xcodeproj'

# Check if the correct number of arguments are provided
if ARGV.length < 2
  puts "Usage: ruby script.rb <project_path> <deployment_target>"
  exit 1
end

project_path = ARGV[0]
deployment_target = ARGV[1]

# Verify if the project path exists
unless File.exist?(project_path)
  puts "Error: Project path '#{project_path}' does not exist."
  exit 1
end

project = Xcodeproj::Project.open(project_path)

project.targets.each do |target|
  target.build_configurations.each do |config|
    config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = deployment_target
  end
end

project.save

puts "Deployment target updated successfully to #{deployment_target} for project at #{project_path}."
