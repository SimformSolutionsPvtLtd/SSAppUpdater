#!/usr/bin/env ruby

# Check if the 'brew' command exists
if system("xcode-select -p > /dev/null 2>&1")
  puts "<output>0</output>"
else
  puts "<output>1</output>"
end
