#!/bin/bash

# Function to generate Podfile
generate_podfile() {
  local ios_min_deployment_target="$1"
  local project_name="$2"
  local include_AWSS3="$3"
  local include_arkana_pods="$4"
  local destination="$5"
  local pod_names_string="$6"

  # If the minimum deployment target is empty, use a default value (e.g., 14.0)
  if [[ -z "$ios_min_deployment_target" ]]; then
    ios_min_deployment_target="14.0"
  fi

  # Convert the pod names string into an array
  IFS=' ' read -r -a default_pods <<< "$pod_names_string"

  # Create the Podfile with the specified configuration
  cat <<EOF > "$destination/Podfile"
platform :ios, '${ios_min_deployment_target}'

# ignore all warnings from all dependencies
inhibit_all_warnings!

target '${project_name}' do

  use_frameworks!

  # Default pods
EOF

  # Loop through the provided pod names and add them to the Podfile
  for pod_name in "${default_pods[@]}"; do
    echo "  pod '${pod_name}'" >> "$destination/Podfile"
  done

  # Conditionally include the Arkana pods if the flag is set
  if [[ "$include_arkana_pods" == "y" ]]; then
    cat <<EOF >> "$destination/Podfile"
  pod '${project_name}Secrets', path: './ArkanaKeys/${project_name}Secrets'
  pod '${project_name}SecretsInterfaces', path: './ArkanaKeys/${project_name}SecretsInterfaces'
EOF
  fi

  # Conditionally include the AWSS3 pod if requested
  if [[ "$include_AWSS3" == "y" ]]; then
    echo "  pod 'AWSS3'" >> "$destination/Podfile"
  fi

  # Complete the Podfile
  cat <<EOF >> "$destination/Podfile"
end

post_install do |installer|
  installer.pods_project.targets.each do |target|
    target.build_configurations.each do |config|
      config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '${ios_min_deployment_target}'
      config.build_settings['CODE_SIGNING_ALLOWED'] = 'NO'
    end
  end
end
EOF
}

# Ensure the correct number of arguments is provided
if [ $# -ne 8 ]; then
  echo "Usage: $0 <ios_minimum_deployment_target> <project_name> <include_AWSS3> <include_arkana_pods> <bundle_identifier> <repo_name> <destination_directory> <pod_names>"
  exit 1
fi

# Get the required arguments
IOS_MIN_DEPLOYMENT_TARGET="$1"
PROJECT_NAME="$2"
INCLUDE_AWSS3="$3"
INCLUDE_ARKANA_PODS="$4"
BUNDLE_IDENTIFIER="$5"
REPO_NAME="$6"
DESTINATION_DIR="$7"
POD_NAMES="$8"

# Generate the Podfile at the specified destination with the provided default pods
generate_podfile "$IOS_MIN_DEPLOYMENT_TARGET" "$PROJECT_NAME" "$INCLUDE_AWSS3" "$INCLUDE_ARKANA_PODS" "$DESTINATION_DIR" "$POD_NAMES"

echo "Podfile has been generated successfully at $DESTINATION_DIR"
