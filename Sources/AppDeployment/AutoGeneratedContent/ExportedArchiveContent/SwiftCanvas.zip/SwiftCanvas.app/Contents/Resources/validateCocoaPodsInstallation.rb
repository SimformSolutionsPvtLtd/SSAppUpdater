#!/usr/bin/env ruby

# Check if the 'pod' command exists
if system("which pod > /dev/null 2>&1")
    puts "<output>0</output>"
else
    puts "<output>1</output>"
end
